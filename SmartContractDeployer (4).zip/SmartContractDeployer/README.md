# EBT Pay Token (EBTP)

A sophisticated Solidity token ecosystem with a separate token sale contract that interacts with an existing BEP-20 token at address `0xCA798C521acDec75D57872BA03c1e7f789e1C4Ca`. The system includes presale functionality, dynamic price feed integration, and a comprehensive referral system.

## Features

### Token Information
- **Name**: EBT Pay
- **Symbol**: EBTP
- **Total Supply**: 1 trillion tokens (1,000,000,000,000 EBTP)
- **Decimals**: 18

### Multi-Phase Presale System
- 4 configurable presale phases
- Each phase can have its own token price, start time, and duration
- 150 billion tokens allocated per phase

### Advanced 5-Level Referral System
- Tiered commission rates:
  - Level 1: 10% (direct referral)
  - Level 2: 5% 
  - Level 3: 3%
  - Level 4: 2%
  - Level 5: 1%
- Qualification requirements: Users must refer at least $1000 value in Level 1 to qualify for Level 2-5 commissions
- All commission rates and eligibility requirements are configurable by the owner

### Purchase Options
- Purchase with USDT or BNB
- Low minimum purchase amount ($1 USDT or equivalent in BNB)
- Configurable minimum requirements by admin/owner

### Airdrop and Distribution Capabilities
- 5% of total supply allocated for airdrops
- Batch airdrop distribution functionality
- Individual and bulk airdrop allocation features

### Integration with External Systems
- PancakeSwap integration for liquidity provisions
- Chainlink price feeds for accurate BNB pricing

### Comprehensive Reporting
- Purchase history tracking
- Commission history tracking by level
- Airdrop claims monitoring

## Contract Structure

The main contract components include:

1. **Token Basics**: Standard ERC-20 implementation with added features
2. **Presale Management**: Phase activation, deactivation, and parameter updates
3. **Purchase Functions**: USDT and BNB purchase options with integrated referral handling
4. **Referral System**: Multi-level tracking and commission distribution
5. **Airdrop Management**: Eligibility setup and claim processing
6. **Admin Controls**: Owner-only functions for contract management

## Deployment

The contract is designed to be deployed on BNB Smart Chain (BSC) and requires the following parameters:
- USDT token address
- PancakeSwap router address
- Chainlink BNB/USD price feed address

## Testing

The contract includes a comprehensive test suite that verifies all major functionality:
- Basic token operations
- Presale phase management
- Token purchases with USDT and BNB
- Referral system at all levels
- Airdrop functionality
- Admin controls

To run tests:
```
npx hardhat test
```

## Security

The contract implements several security measures:
- Input validation for all functions
- Overflow protection using SafeMath
- Access controls for admin functions
- Checks for sufficient balance and allowances

## Owner and Admin Address

The specified owner and admin address is `0x1C040239180eEfc44f1F85996C8EC7833dD477a8`. This address has special privileges for contract management.
