# EBTP Token Sale Deployment Guide

This guide provides instructions for deploying the EBTP Token Sale contract that will be used to sell the existing EBTP token at address `0xCA798C521acDec75D57872BA03c1e7f789e1C4Ca`.

## Prerequisites

1. Make sure you have a wallet with enough BNB for deployment (recommend at least 0.1 BNB for testnet or 0.5 BNB for mainnet).
2. Make sure the private key is configured in the `.env` file.
3. Make sure you have an API key for BSCScan verification (already set as BSCSCAN_API_KEY in your environment).

## Step 1: Deploy to BSC Testnet (Testing)

Run the following command to deploy the token sale contract to BSC Testnet:

```bash
npx hardhat run --network bscTestnet scripts/deploy-token-sale-testnet.js
```

This will output:
- The token sale contract address
- Verification command for BSCScan

## Step 2: Deploy to BSC Mainnet (Production)

Once testing is complete and you're ready for production, deploy to BSC Mainnet:

```bash
npx hardhat run --network bsc scripts/deploy-token-sale.js
```

## Step 3: Verify on BSCScan

Use the verification command provided after deployment:

For Testnet:
```bash
npx hardhat verify --network bscTestnet DEPLOYED_CONTRACT_ADDRESS 0xCA798C521acDec75D57872BA03c1e7f789e1C4Ca 0x337610d27c682E347C9cD60BD4b3b107C9d34dDd 0xD99D1c33F9fC3444f8101754aBC46c52416550D1 0x2514895c72f50D8bd4B4F9b1110F0D6bD2c97526
```

For Mainnet:
```bash
npx hardhat verify --network bsc DEPLOYED_CONTRACT_ADDRESS 0xCA798C521acDec75D57872BA03c1e7f789e1C4Ca 0x55d398326f99059fF775485246999027B3197955 0x10ED43C718714eb63d5aA57B78B54704E256024E 0x0567F2323251f0Aab15c8dFb1967E4e8A7D42aeE
```

## Step 4: Update Frontend Configuration

After deploying the token sale contract, update the address in `src/utils/web3.js`:

```javascript
// Find this line:
export const EBT_TOKEN_SALE_ADDRESS = '0x0000000000000000000000000000000000000000';

// Replace with your deployed contract address:
export const EBT_TOKEN_SALE_ADDRESS = 'YOUR_DEPLOYED_CONTRACT_ADDRESS';
```

## Step 5: Contract Owner Setup

After deployment, the owner (deployer) address should perform the following setup actions:

1. Set admin address (if different from owner):
   ```javascript
   await saleContract.setAdmin("ADMIN_ADDRESS");
   ```

2. Activate presale phases:
   ```javascript
   // Phase 0 (first phase) with $0.01 price, starting now, lasting 30 days
   const now = Math.floor(Date.now() / 1000);
   const duration = 30 * 24 * 60 * 60; // 30 days in seconds
   const tokenPrice = ethers.utils.parseUnits("0.01", 18); // $0.01 per token
   await saleContract.activatePhase(0, now, duration, tokenPrice);
   ```

3. Update referral rates if needed:
   ```javascript
   // Default is already 10%, 5%, 3%, 2%, 1%
   await saleContract.updateReferralRates(1000, 500, 300, 200, 100);
   ```

4. Set up bonus parameters:
   ```javascript
   // 20% bonus for purchases of $100 or more
   const threshold = ethers.utils.parseUnits("100", 18);
   await saleContract.updateBonusParameters(threshold, 20);
   ```

5. Set minimum purchase amounts:
   ```javascript
   // Minimum $10 USDT or 0.05 BNB
   const minUsdt = ethers.utils.parseUnits("10", 18);
   const minBnb = ethers.utils.parseUnits("0.05", 18);
   await saleContract.updateMinimumPurchaseAmounts(minUsdt, minBnb);
   ```

6. Transfer EBT tokens to the sale contract:
   ```javascript
   // The sale contract needs EBT tokens to distribute to buyers
   // Transfer 600 billion tokens (150B * 4 phases) plus 50B for airdrops
   const ebtToken = new ethers.Contract(
     "0xCA798C521acDec75D57872BA03c1e7f789e1C4Ca",
     ERC20ABI,
     signer
   );
   
   const amount = ethers.utils.parseUnits("650000000000", 18); // 650 billion tokens
   await ebtToken.transfer(saleContract.address, amount);
   ```

## Important Security Notes

1. Make sure the owner's private key is secured and not exposed.
2. After verification, keep a backup of the contract address and ABI.
3. Monitor the contract regularly for any suspicious activity.
4. Consider setting up a multi-sig wallet for added security when managing the contract.