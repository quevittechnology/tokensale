# EBT Pay Token Sale Contract

This project provides a token sale mechanism for the existing EBT token (located at 0xCA798C521acDec75D57872BA03c1e7f789e1C4Ca). The system supports multi-phase presales, a 5-level referral system, and both USDT and BNB payment options.

## Key Features

### Token Sale Features
- Sell existing BEP-20 token at address 0xCA798C521acDec75D57872BA03c1e7f789e1C4Ca
- Multi-phase presale with configurable prices, start times, and durations
- Support for both USDT and BNB purchases
- 20% bonus for purchases over $100 USD equivalent
- Minimum purchase thresholds configurable by admin

### Referral System
- 5-level deep referral system with commissions paid in USDT
- Referral commission rates: 10%, 5%, 3%, 2%, 1%
- Qualification threshold for multi-level commissions
- Referral link generation for easy sharing

### Airdrop Management
- Separate 5-level airdrop referral system
- Airdrop commissions paid in tokens
- Batch airdrop allocation capabilities
- Individual airdrop tracking and management

### Admin Features
- Detailed sales and commission reporting
- Phase activation/deactivation controls
- Parameter adjustment capabilities
- Configurable pricing and commission rates

## Technical Stack
- Solidity Smart Contract
- Hardhat development environment
- OpenZeppelin contract standards
- React.js frontend with ethers.js
- PancakeSwap integration for liquidity
- Chainlink price feeds for BNB/USD rates

## Deployment
See DEPLOYMENT_INSTRUCTIONS.txt for detailed deployment steps.
