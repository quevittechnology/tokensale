const { expect } = require("chai");
const { ethers } = require("hardhat");

describe("EBTToken", function () {
  let EBTToken;
  let ebtToken;
  let MockERC20;
  let mockUsdt;
  let MockChainlinkPriceFeed;
  let mockPriceFeed;
  let MockUniswapV2Router;
  let mockRouter;
  let owner;
  let addr1;
  let addr2;
  let addr3;
  let addr4;
  let addr5;
  let addr6;
  let addrs;

  beforeEach(async function () {
    // Deploy mock tokens and dependencies
    [owner, addr1, addr2, addr3, addr4, addr5, addr6, ...addrs] = await ethers.getSigners();
    
    MockERC20 = await ethers.getContractFactory("MockERC20");
    mockUsdt = await MockERC20.deploy(
      "Mock USDT", 
      "mUSDT", 
      ethers.utils.parseEther("1000000") // 1 million USDT
    );
    await mockUsdt.deployed();
    
    MockChainlinkPriceFeed = await ethers.getContractFactory("MockChainlinkPriceFeed");
    mockPriceFeed = await MockChainlinkPriceFeed.deploy(
      "30000000000", // $300 with 8 decimals
      8 // 8 decimals
    );
    await mockPriceFeed.deployed();
    
    MockUniswapV2Router = await ethers.getContractFactory("MockUniswapV2Router");
    mockRouter = await MockUniswapV2Router.deploy(
      mockUsdt.address, // Using USDT as fake factory address for simplicity
      mockUsdt.address  // Using USDT as fake WETH address for simplicity
    );
    await mockRouter.deployed();
    
    // Deploy the main EBT Token
    EBTToken = await ethers.getContractFactory("EBTToken");
    ebtToken = await EBTToken.deploy(
      mockUsdt.address,
      mockRouter.address,
      mockPriceFeed.address
    );
    await ebtToken.deployed();
    
    // Transfer some USDT to test accounts
    await mockUsdt.transfer(addr1.address, ethers.utils.parseEther("10000"));
    await mockUsdt.transfer(addr2.address, ethers.utils.parseEther("10000"));
    await mockUsdt.transfer(addr3.address, ethers.utils.parseEther("10000"));
  });

  describe("Deployment", function () {
    it("Should set the right owner", async function () {
      expect(await ebtToken.owner()).to.equal(owner.address);
    });

    it("Should have correct token name and symbol", async function () {
      expect(await ebtToken.name()).to.equal("EBT Pay");
      expect(await ebtToken.symbol()).to.equal("EBTP");
    });

    it("Should have the correct total supply", async function () {
      const totalSupply = await ebtToken.TOTAL_SUPPLY();
      expect(await ebtToken.balanceOf(ebtToken.address)).to.equal(totalSupply);
    });

    it("Should have the correct external addresses set", async function () {
      expect(await ebtToken.usdtTokenAddress()).to.equal(mockUsdt.address);
      expect(await ebtToken.admin()).to.equal(owner.address);
      // Test other external addresses
    });
  });

  describe("Presale Phases", function () {
    beforeEach(async function () {
      // Activate first presale phase
      const currentTime = Math.floor(Date.now() / 1000);
      const duration = 60 * 60 * 24 * 7; // 7 days
      const tokenPrice = ethers.utils.parseEther("0.0001"); // $0.0001 per token
      
      await ebtToken.activatePhase(0, currentTime, duration, tokenPrice);
    });

    it("Should correctly activate a presale phase", async function () {
      const currentTime = Math.floor(Date.now() / 1000);
      const phase = await ebtToken.presalePhases(0);
      
      expect(phase.active).to.equal(true);
      expect(phase.startTime).to.be.closeTo(ethers.BigNumber.from(currentTime), 10); // Allow small deviation
      expect(phase.tokenPrice).to.equal(ethers.utils.parseEther("0.0001"));
    });

    it("Should allow token purchase with USDT during active phase", async function () {
      const purchaseAmount = ethers.utils.parseEther("100"); // 100 USDT
      
      // Approve USDT spending
      await mockUsdt.connect(addr1).approve(ebtToken.address, purchaseAmount);
      
      // Purchase tokens
      await ebtToken.connect(addr1).purchaseTokensWithUSDT(purchaseAmount, ethers.constants.AddressZero);
      
      // Calculate expected tokens: 100 USDT / 0.0001 USDT per token = 1,000,000 tokens
      // Plus 20% bonus for purchase over $100: 1,000,000 * 1.2 = 1,200,000 tokens
      const expectedTokens = ethers.utils.parseEther("1000000").mul(120).div(100);
      
      expect(await ebtToken.balanceOf(addr1.address)).to.equal(expectedTokens);
    });

    it("Should not apply bonus for smaller purchases", async function () {
      const purchaseAmount = ethers.utils.parseEther("50"); // 50 USDT (below $100 threshold)
      
      // Approve USDT spending
      await mockUsdt.connect(addr1).approve(ebtToken.address, purchaseAmount);
      
      // Purchase tokens
      await ebtToken.connect(addr1).purchaseTokensWithUSDT(purchaseAmount, ethers.constants.AddressZero);
      
      // Calculate expected tokens: 50 USDT / 0.0001 USDT per token = 500,000 tokens
      // No bonus for purchase under $100
      const expectedTokens = ethers.utils.parseEther("500000");
      
      expect(await ebtToken.balanceOf(addr1.address)).to.equal(expectedTokens);
    });

    it("Should allow token purchase with BNB", async function () {
      const bnbAmount = ethers.utils.parseEther("0.5"); // 0.5 BNB
      
      // Purchase tokens with BNB
      await ebtToken.connect(addr1).purchaseTokensWithBNB(
        ethers.constants.AddressZero,
        { value: bnbAmount }
      );
      
      // BNB price is $300, so 0.5 BNB = $150
      // $150 / 0.0001 USDT per token = 1,500,000 tokens
      // Plus 20% bonus = 1,800,000 tokens
      const expectedTokens = ethers.utils.parseEther("1500000").mul(120).div(100);
      
      // Allow a small margin of error due to calculation precision
      const balance = await ebtToken.balanceOf(addr1.address);
      expect(balance).to.be.closeTo(expectedTokens, ethers.utils.parseEther("1"));
    });
  });

  describe("Referral System", function () {
    beforeEach(async function () {
      // Activate presale
      const currentTime = Math.floor(Date.now() / 1000);
      const duration = 60 * 60 * 24 * 7; // 7 days
      const tokenPrice = ethers.utils.parseEther("0.0001"); // $0.0001 per token
      
      await ebtToken.activatePhase(0, currentTime, duration, tokenPrice);
      
      // Transfer more USDT to test accounts
      await mockUsdt.transfer(addr4.address, ethers.utils.parseEther("10000"));
      await mockUsdt.transfer(addr5.address, ethers.utils.parseEther("10000"));
      await mockUsdt.transfer(addr6.address, ethers.utils.parseEther("10000"));
      
      // Approve USDT spending for all test accounts
      const approveAmount = ethers.utils.parseEther("10000");
      await mockUsdt.connect(addr1).approve(ebtToken.address, approveAmount);
      await mockUsdt.connect(addr2).approve(ebtToken.address, approveAmount);
      await mockUsdt.connect(addr3).approve(ebtToken.address, approveAmount);
      await mockUsdt.connect(addr4).approve(ebtToken.address, approveAmount);
      await mockUsdt.connect(addr5).approve(ebtToken.address, approveAmount);
      await mockUsdt.connect(addr6).approve(ebtToken.address, approveAmount);
    });

    it("Should pay level 1 referral commission in USDT", async function () {
      const purchaseAmount = ethers.utils.parseEther("1000"); // 1000 USDT
      const initialReferrerBalance = await mockUsdt.balanceOf(addr2.address);
      
      // Purchase tokens with referral
      await ebtToken.connect(addr1).purchaseTokensWithUSDT(purchaseAmount, addr2.address);
      
      // Level 1 commission: 10% of 1000 USDT = 100 USDT
      const expectedCommission = ethers.utils.parseEther("100");
      const finalReferrerBalance = await mockUsdt.balanceOf(addr2.address);
      
      expect(finalReferrerBalance.sub(initialReferrerBalance)).to.equal(expectedCommission);
    });

    it("Should correctly track purchase and commission history", async function () {
      const purchaseAmount = ethers.utils.parseEther("1000"); // 1000 USDT
      
      // Purchase tokens with referral
      await ebtToken.connect(addr1).purchaseTokensWithUSDT(purchaseAmount, addr2.address);
      
      // Check purchase history
      expect(await ebtToken.getPurchaseCount(addr1.address)).to.equal(1);
      const [amount, cost, , paymentMethod, bonusAmount] = await ebtToken.getPurchaseDetails(addr1.address, 0);
      expect(amount).to.equal(ethers.utils.parseEther("10000000")); // 1000 USDT / 0.0001 = 10M tokens
      expect(cost).to.equal(purchaseAmount);
      expect(paymentMethod).to.equal("USDT");
      expect(bonusAmount).to.equal(ethers.utils.parseEther("2000000")); // 20% of 10M = 2M
      
      // Check commission history
      expect(await ebtToken.getCommissionCount(addr2.address)).to.equal(1);
      const [referee, commission, , , level] = await ebtToken.getCommissionDetails(addr2.address, 0);
      expect(referee).to.equal(addr1.address);
      expect(commission).to.equal(ethers.utils.parseEther("100")); // 10% of 1000 USDT
      expect(level).to.equal(1);
    });

    it("Should handle multi-level referrals correctly when threshold is met", async function () {
      // First purchase (>$1000) to make addr2 eligible for multi-level
      await ebtToken.connect(addr1).purchaseTokensWithUSDT(ethers.utils.parseEther("1100"), addr2.address);
      
      // Check that addr2 is now eligible for multi-level
      expect(await ebtToken.isEligibleForMultiLevel(addr2.address)).to.equal(true);
      
      // Second purchase with addr2 as referrer for addr3
      await ebtToken.connect(addr3).purchaseTokensWithUSDT(ethers.utils.parseEther("1100"), addr2.address);
      
      // Third purchase with addr3 as referrer for addr4, addr2 should get level 2 commission
      const balanceBefore = await mockUsdt.balanceOf(addr2.address);
      await ebtToken.connect(addr4).purchaseTokensWithUSDT(ethers.utils.parseEther("1000"), addr3.address);
      const balanceAfter = await mockUsdt.balanceOf(addr2.address);
      
      // Level 2 commission for addr2: 5% of 1000 USDT = 50 USDT
      const level2Commission = ethers.utils.parseEther("50");
      expect(balanceAfter.sub(balanceBefore)).to.equal(level2Commission);
      
      // Fourth purchase: build a 5-level chain
      await ebtToken.connect(addr5).purchaseTokensWithUSDT(ethers.utils.parseEther("1100"), addr4.address);
      await ebtToken.connect(addr6).purchaseTokensWithUSDT(ethers.utils.parseEther("1100"), addr5.address);
      
      // Final purchase to test level 3-5 commissions
      const addr1Before = await mockUsdt.balanceOf(addr1.address);
      const addr2Before = await mockUsdt.balanceOf(addr2.address);
      const addr3Before = await mockUsdt.balanceOf(addr3.address);
      const addr4Before = await mockUsdt.balanceOf(addr4.address);
      const addr5Before = await mockUsdt.balanceOf(addr5.address);
      
      // Make big purchase from a new address
      await mockUsdt.transfer(addrs[0].address, ethers.utils.parseEther("10000"));
      await mockUsdt.connect(addrs[0]).approve(ebtToken.address, ethers.utils.parseEther("5000"));
      await ebtToken.connect(addrs[0]).purchaseTokensWithUSDT(ethers.utils.parseEther("5000"), addr6.address);
      
      const addr1After = await mockUsdt.balanceOf(addr1.address);
      const addr2After = await mockUsdt.balanceOf(addr2.address);
      const addr3After = await mockUsdt.balanceOf(addr3.address);
      const addr4After = await mockUsdt.balanceOf(addr4.address);
      const addr5After = await mockUsdt.balanceOf(addr5.address);
      
      // Commissions:
      // Level 1 (addr6): 10% of 5000 = 500 USDT
      // Level 2 (addr5): 5% of 5000 = 250 USDT
      // Level 3 (addr4): 3% of 5000 = 150 USDT
      // Level 4 (addr3): 2% of 5000 = 100 USDT
      // Level 5 (addr2): 1% of 5000 = 50 USDT
      
      expect(addr5After.sub(addr5Before)).to.equal(ethers.utils.parseEther("250"));
      expect(addr4After.sub(addr4Before)).to.equal(ethers.utils.parseEther("150"));
      expect(addr3After.sub(addr3Before)).to.equal(ethers.utils.parseEther("100"));
      expect(addr2After.sub(addr2Before)).to.equal(ethers.utils.parseEther("50"));
      expect(addr1After.sub(addr1Before)).to.equal(ethers.utils.parseEther("0")); // Not in chain
    });
  });

  describe("Airdrop System", function () {
    it("Should allow setting airdrop allocations", async function () {
      const airdropAmount = ethers.utils.parseEther("10000"); // 10,000 tokens
      
      await ebtToken.setAirdropExternal(addr1.address, airdropAmount);
      
      const [eligible, claimed, amount, referrer] = await ebtToken.getAirdropDetails(addr1.address);
      expect(eligible).to.equal(true);
      expect(claimed).to.equal(false);
      expect(amount).to.equal(airdropAmount);
      expect(referrer).to.equal(ethers.constants.AddressZero);
    });

    it("Should allow airdrop claiming", async function () {
      const airdropAmount = ethers.utils.parseEther("10000"); // 10,000 tokens
      
      await ebtToken.setAirdropExternal(addr1.address, airdropAmount);
      await ebtToken.connect(addr1).claimAirdrop();
      
      expect(await ebtToken.balanceOf(addr1.address)).to.equal(airdropAmount);
      
      const [eligible, claimed, , ] = await ebtToken.getAirdropDetails(addr1.address);
      expect(eligible).to.equal(true);
      expect(claimed).to.equal(true);
    });

    it("Should handle airdrop referrals correctly", async function () {
      // Generate referral link for addr2
      await ebtToken.connect(addr2).generateReferralLink();
      const referralLink = await ebtToken.getReferralLink(addr2.address);
      
      // Register addr1 using addr2's referral link
      await ebtToken.connect(addr1).registerForAirdrop(referralLink);
      
      // Set up airdrop for addr1
      const airdropAmount = ethers.utils.parseEther("10000"); // 10,000 tokens
      await ebtToken.setAirdropExternal(addr1.address, airdropAmount);
      
      // Check referrer was set correctly
      const [, , , referrer] = await ebtToken.getAirdropDetails(addr1.address);
      expect(referrer).to.equal(addr2.address);
      
      // Check initial balances
      const initialReferrerBalance = await ebtToken.balanceOf(addr2.address);
      
      // Claim the airdrop
      await ebtToken.connect(addr1).claimAirdrop();
      
      // Check commissions were paid in EBTP tokens
      // Level 1 commission: 10% of 10,000 = 1,000 tokens
      const expectedCommission = ethers.utils.parseEther("1000");
      const finalReferrerBalance = await ebtToken.balanceOf(addr2.address);
      
      expect(finalReferrerBalance.sub(initialReferrerBalance)).to.equal(expectedCommission);
      
      // Check airdrop commission history
      expect(await ebtToken.getAirdropCommissionCount(addr2.address)).to.equal(1);
      const [airdropReferee, airdropCommission, airdropAmount_, , airdropLevel] = 
        await ebtToken.getAirdropCommissionDetails(addr2.address, 0);
      
      expect(airdropReferee).to.equal(addr1.address);
      expect(airdropCommission).to.equal(expectedCommission);
      expect(airdropAmount_).to.equal(airdropAmount);
      expect(airdropLevel).to.equal(1);
    });

    it("Should handle multi-level airdrop referrals", async function () {
      // Generate referral links
      await ebtToken.connect(addr1).generateReferralLink();
      await ebtToken.connect(addr2).generateReferralLink();
      await ebtToken.connect(addr3).generateReferralLink();
      await ebtToken.connect(addr4).generateReferralLink();
      await ebtToken.connect(addr5).generateReferralLink();
      
      const link1 = await ebtToken.getReferralLink(addr1.address);
      const link2 = await ebtToken.getReferralLink(addr2.address);
      const link3 = await ebtToken.getReferralLink(addr3.address);
      const link4 = await ebtToken.getReferralLink(addr4.address);
      const link5 = await ebtToken.getReferralLink(addr5.address);
      
      // Create a referral chain: addr1 <- addr2 <- addr3 <- addr4 <- addr5 <- addr6
      await ebtToken.connect(addr2).registerForAirdrop(link1);
      await ebtToken.connect(addr3).registerForAirdrop(link2);
      await ebtToken.connect(addr4).registerForAirdrop(link3);
      await ebtToken.connect(addr5).registerForAirdrop(link4);
      await ebtToken.connect(addr6).registerForAirdrop(link5);
      
      // Set airdrop for addr6
      const airdropAmount = ethers.utils.parseEther("10000"); // 10,000 tokens
      await ebtToken.setAirdropExternal(addr6.address, airdropAmount);
      
      // Record initial balances
      const initialBalance1 = await ebtToken.balanceOf(addr1.address);
      const initialBalance2 = await ebtToken.balanceOf(addr2.address);
      const initialBalance3 = await ebtToken.balanceOf(addr3.address);
      const initialBalance4 = await ebtToken.balanceOf(addr4.address);
      const initialBalance5 = await ebtToken.balanceOf(addr5.address);
      
      // Claim airdrop
      await ebtToken.connect(addr6).claimAirdrop();
      
      // Check commissions at each level
      // Level 1 (addr5): 10% of 10,000 = 1,000 tokens
      // Level 2 (addr4): 5% of 10,000 = 500 tokens
      // Level 3 (addr3): 3% of 10,000 = 300 tokens
      // Level 4 (addr2): 2% of 10,000 = 200 tokens
      // Level 5 (addr1): 1% of 10,000 = 100 tokens
      
      const finalBalance1 = await ebtToken.balanceOf(addr1.address);
      const finalBalance2 = await ebtToken.balanceOf(addr2.address);
      const finalBalance3 = await ebtToken.balanceOf(addr3.address);
      const finalBalance4 = await ebtToken.balanceOf(addr4.address);
      const finalBalance5 = await ebtToken.balanceOf(addr5.address);
      
      expect(finalBalance5.sub(initialBalance5)).to.equal(ethers.utils.parseEther("1000"));
      expect(finalBalance4.sub(initialBalance4)).to.equal(ethers.utils.parseEther("500"));
      expect(finalBalance3.sub(initialBalance3)).to.equal(ethers.utils.parseEther("300"));
      expect(finalBalance2.sub(initialBalance2)).to.equal(ethers.utils.parseEther("200"));
      expect(finalBalance1.sub(initialBalance1)).to.equal(ethers.utils.parseEther("100"));
    });
  });

  describe("Admin Functions", function () {
    it("Should allow admin to change referral rates", async function () {
      await ebtToken.updateReferralRates(
        1200, // 12%
        600,  // 6%
        400,  // 4%
        300,  // 3%
        200   // 2%
      );
      
      expect(await ebtToken.level1ReferralBonus()).to.equal(1200);
      expect(await ebtToken.level2ReferralBonus()).to.equal(600);
      expect(await ebtToken.level3ReferralBonus()).to.equal(400);
      expect(await ebtToken.level4ReferralBonus()).to.equal(300);
      expect(await ebtToken.level5ReferralBonus()).to.equal(200);
    });

    it("Should allow admin to change admin address", async function () {
      await ebtToken.setAdmin(addr1.address);
      expect(await ebtToken.admin()).to.equal(addr1.address);
    });

    it("Should allow admin to change token price", async function () {
      const currentTime = Math.floor(Date.now() / 1000);
      const duration = 60 * 60 * 24 * 7; // 7 days
      const tokenPrice = ethers.utils.parseEther("0.0001"); // $0.0001 per token
      
      await ebtToken.activatePhase(0, currentTime, duration, tokenPrice);
      
      const newPrice = ethers.utils.parseEther("0.0002"); // $0.0002 per token
      await ebtToken.updateTokenPrice(0, newPrice);
      
      const phase = await ebtToken.presalePhases(0);
      expect(phase.tokenPrice).to.equal(newPrice);
    });

    it("Should allow batch airdrop allocations", async function () {
      const recipients = [addr1.address, addr2.address, addr3.address];
      const amounts = [
        ethers.utils.parseEther("10000"),
        ethers.utils.parseEther("20000"),
        ethers.utils.parseEther("30000")
      ];
      
      await ebtToken.batchSetAirdrop(recipients, amounts);
      
      // Check first recipient
      const [eligible1, claimed1, amount1, ] = await ebtToken.getAirdropDetails(addr1.address);
      expect(eligible1).to.equal(true);
      expect(claimed1).to.equal(false);
      expect(amount1).to.equal(amounts[0]);
      
      // Check second recipient
      const [eligible2, claimed2, amount2, ] = await ebtToken.getAirdropDetails(addr2.address);
      expect(eligible2).to.equal(true);
      expect(claimed2).to.equal(false);
      expect(amount2).to.equal(amounts[1]);
      
      // Check third recipient
      const [eligible3, claimed3, amount3, ] = await ebtToken.getAirdropDetails(addr3.address);
      expect(eligible3).to.equal(true);
      expect(claimed3).to.equal(false);
      expect(amount3).to.equal(amounts[2]);
    });
  });

  describe("Administrative Reporting", function () {
    beforeEach(async function () {
      // Activate presale
      const currentTime = Math.floor(Date.now() / 1000);
      const duration = 60 * 60 * 24 * 7; // 7 days
      const tokenPrice = ethers.utils.parseEther("0.0001"); // $0.0001 per token
      
      await ebtToken.activatePhase(0, currentTime, duration, tokenPrice);
      
      // Make some purchases
      await mockUsdt.connect(addr1).approve(ebtToken.address, ethers.utils.parseEther("5000"));
      await ebtToken.connect(addr1).purchaseTokensWithUSDT(ethers.utils.parseEther("1000"), addr2.address);
      await ebtToken.connect(addr1).purchaseTokensWithUSDT(ethers.utils.parseEther("2000"), addr2.address);
      
      // Set up and claim some airdrops
      await ebtToken.connect(addr2).generateReferralLink();
      const referralLink = await ebtToken.getReferralLink(addr2.address);
      await ebtToken.connect(addr3).registerForAirdrop(referralLink);
      
      await ebtToken.setAirdropExternal(addr3.address, ethers.utils.parseEther("5000"));
      await ebtToken.connect(addr3).claimAirdrop();
    });

    it("Should track total tokens sold accurately", async function () {
      const [tokensSold, , , , , , , ] = await ebtToken.getAdminReport();
      
      // 1000 USDT purchase: 1000/0.0001 = 10M tokens + 2M bonus (20%)
      // 2000 USDT purchase: 2000/0.0001 = 20M tokens + 4M bonus (20%)
      // Total: 36M tokens
      const expectedTokensSold = ethers.utils.parseEther("36000000");
      
      expect(tokensSold).to.equal(expectedTokensSold);
    });

    it("Should track total USDT collected accurately", async function () {
      const [, usdtCollected, , , , , , ] = await ebtToken.getAdminReport();
      
      // 1000 USDT + 2000 USDT = 3000 USDT
      const expectedUsdtCollected = ethers.utils.parseEther("3000");
      
      expect(usdtCollected).to.equal(expectedUsdtCollected);
    });

    it("Should track total commissions paid accurately", async function () {
      const [, , , commissionsPaid, , , , ] = await ebtToken.getAdminReport();
      
      // 10% of 1000 USDT = 100 USDT
      // 10% of 2000 USDT = 200 USDT
      // Total: 300 USDT
      const expectedCommissionsPaid = ethers.utils.parseEther("300");
      
      expect(commissionsPaid).to.equal(expectedCommissionsPaid);
    });

    it("Should track total airdrop allocations and claims accurately", async function () {
      const [, , , , , airdropsAllocated, airdropsClaimed, ] = await ebtToken.getAdminReport();
      
      const expectedAirdropsAllocated = ethers.utils.parseEther("5000");
      const expectedAirdropsClaimed = ethers.utils.parseEther("5000");
      
      expect(airdropsAllocated).to.equal(expectedAirdropsAllocated);
      expect(airdropsClaimed).to.equal(expectedAirdropsClaimed);
    });

    it("Should track total airdrop commissions paid accurately", async function () {
      const [, , , , , , , airdropCommissionsPaid] = await ebtToken.getAdminReport();
      
      // 10% of 5000 tokens = 500 tokens
      const expectedAirdropCommissionsPaid = ethers.utils.parseEther("500");
      
      expect(airdropCommissionsPaid).to.equal(expectedAirdropCommissionsPaid);
    });
  });
});
