const { ethers } = require("hardhat");

async function main() {
  console.log("Deploying EBTTokenSale contract to BSC Testnet...");
  
  // Get the deployer account
  const [deployer] = await ethers.getSigners();
  console.log("Deploying from account:", deployer.address);
  
  // Contract configuration for BSC Testnet
  const ebtTokenAddress = "0xCA798C521acDec75D57872BA03c1e7f789e1C4Ca"; // The existing token address on BSC Testnet
  const usdtTokenAddress = "0x337610d27c682E347C9cD60BD4b3b107C9d34dDd"; // USDT BSC Testnet address
  
  // PancakeSwap and Chainlink addresses on BSC Testnet
  const pancakeRouterAddress = "0xD99D1c33F9fC3444f8101754aBC46c52416550D1"; // PancakeSwap Router on Testnet
  const priceFeedAddress = "0x2514895c72f50D8bd4B4F9b1110F0D6bD2c97526"; // BNB/USD Chainlink Price Feed on Testnet
  
  // Deploy the TokenSale contract
  const EBTTokenSale = await ethers.getContractFactory("EBTTokenSale");
  const tokenSale = await EBTTokenSale.deploy(
    ebtTokenAddress,
    usdtTokenAddress,
    pancakeRouterAddress,
    priceFeedAddress
  );
  
  await tokenSale.deployed();
  
  console.log("EBTTokenSale contract deployed to:", tokenSale.address);
  console.log("Using EBT token at:", ebtTokenAddress);
  
  // Add verification information
  console.log("\nTo verify the contract on BSCScan:");
  console.log(`npx hardhat verify --network bsctestnet ${tokenSale.address} ${ebtTokenAddress} ${usdtTokenAddress} ${pancakeRouterAddress} ${priceFeedAddress}`);
}

main()
  .then(() => process.exit(0))
  .catch((error) => {
    console.error(error);
    process.exit(1);
  });