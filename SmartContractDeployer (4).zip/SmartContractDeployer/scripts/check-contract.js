// Script to check deployed contract details
const { ethers } = require("hardhat");
require("dotenv").config();

async function main() {
  // Contract address on BSC Testnet
  const contractAddress = "0xe2ef291fC99EF3fBf5918a52e85C1DcA7ac0744a";
  
  // Connect to BSC Testnet
  const provider = new ethers.providers.JsonRpcProvider("https://data-seed-prebsc-1-s1.binance.org:8545");
  
  // Get the contract ABI
  const EBTToken = await ethers.getContractFactory("EBTToken");
  const contract = EBTToken.attach(contractAddress).connect(provider);
  
  console.log("=== EBT Pay Token Contract Information ===");
  console.log(`Contract Address: ${contractAddress}`);
  console.log(`View on BSCScan: https://testnet.bscscan.com/address/${contractAddress}`);
  
  try {
    // Basic token information
    const name = await contract.name();
    const symbol = await contract.symbol();
    const decimals = await contract.decimals();
    const totalSupply = await contract.totalSupply();
    const formattedSupply = ethers.utils.formatUnits(totalSupply, decimals);
    
    console.log("\n=== Token Details ===");
    console.log(`Name: ${name}`);
    console.log(`Symbol: ${symbol}`);
    console.log(`Decimals: ${decimals}`);
    console.log(`Total Supply: ${formattedSupply} ${symbol}`);
    
    // Owner information
    const owner = await contract.owner();
    console.log(`\nContract Owner: ${owner}`);
    
    // Presale information
    try {
      const currentPhase = await contract.getCurrentPhase();
      console.log("\n=== Presale Status ===");
      console.log(`Current Phase: ${currentPhase}`);
      
      // Try to get details of all phases
      console.log("\n=== Presale Phases ===");
      for (let i = 1; i <= 4; i++) {
        try {
          const phase = await contract.getPresalePhase(i);
          console.log(`Phase ${i}:`);
          console.log(`  Active: ${phase.isActive}`);
          console.log(`  Price (USD): $${ethers.utils.formatUnits(phase.tokenPrice, 18)}`);
          console.log(`  Tokens Sold: ${ethers.utils.formatUnits(phase.tokensSold, 18)}`);
          console.log(`  Start Time: ${new Date(phase.startTime.toNumber() * 1000).toLocaleString()}`);
          console.log(`  End Time: ${phase.endTime.toNumber() > 0 ? new Date(phase.endTime.toNumber() * 1000).toLocaleString() : 'Not set'}`);
        } catch (error) {
          console.log(`  Error retrieving Phase ${i}: ${error.message}`);
        }
      }
    } catch (error) {
      console.log(`Error retrieving presale data: ${error.message}`);
    }
    
    // Referral information
    console.log("\n=== Referral System ===");
    try {
      const rates = [];
      for (let i = 0; i < 5; i++) {
        const rate = await contract.referralCommissionRates(i);
        rates.push(rate.toString());
      }
      console.log(`Referral Commission Rates: ${rates.join(', ')}%`);
    } catch (error) {
      console.log(`Error retrieving referral data: ${error.message}`);
    }
    
    // Airdrop information
    console.log("\n=== Airdrop Status ===");
    try {
      const airdropAllocated = await contract.getTotalAirdropAllocated();
      const airdropClaimed = await contract.getTotalAirdropClaimed();
      console.log(`Total Allocated: ${ethers.utils.formatUnits(airdropAllocated, 18)} ${symbol}`);
      console.log(`Total Claimed: ${ethers.utils.formatUnits(airdropClaimed, 18)} ${symbol}`);
    } catch (error) {
      console.log(`Error retrieving airdrop data: ${error.message}`);
    }
    
    // External contract addresses
    console.log("\n=== External Contracts ===");
    try {
      const usdtAddress = await contract.usdtToken();
      const pancakeRouterAddress = await contract.pancakeRouter();
      const priceFeedAddress = await contract.bnbUsdPriceFeed();
      
      console.log(`USDT Address: ${usdtAddress}`);
      console.log(`PancakeSwap Router: ${pancakeRouterAddress}`);
      console.log(`BNB/USD Price Feed: ${priceFeedAddress}`);
    } catch (error) {
      console.log(`Error retrieving external contracts: ${error.message}`);
    }
    
  } catch (error) {
    console.error("Error checking contract details:", error);
  }
  
  console.log("\n=== Contract Verification Status ===");
  console.log("Check if contract is verified at:");
  console.log(`https://testnet.bscscan.com/address/${contractAddress}#code`);
}

main()
  .then(() => process.exit(0))
  .catch((error) => {
    console.error(error);
    process.exit(1);
  });