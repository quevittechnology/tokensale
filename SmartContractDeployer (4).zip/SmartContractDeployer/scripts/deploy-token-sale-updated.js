const { ethers } = require("hardhat");

async function main() {
  console.log("Deploying EBTTokenSaleUpdated contract to BSC Mainnet...");
  
  // Get the deployer account
  const [deployer] = await ethers.getSigners();
  console.log("Deploying from account:", deployer.address);
  
  // Contract configuration for BSC Mainnet
  const ebtTokenAddress = "0xCA798C521acDec75D57872BA03c1e7f789e1C4Ca"; // The existing token address on BSC Mainnet (replace with actual)
  const usdtTokenAddress = "0x55d398326f99059fF775485246999027B3197955"; // USDT BSC Mainnet address
  
  // PancakeSwap and Chainlink addresses on BSC Mainnet
  const pancakeRouterAddress = "0x10ED43C718714eb63d5aA57B78B54704E256024E"; // PancakeSwap Router on Mainnet
  const priceFeedAddress = "0x0567F2323251f0Aab15c8dFb1967E4e8A7D42aeE"; // BNB/USD Chainlink Price Feed on Mainnet
  
  // Deploy the Updated TokenSale contract
  const EBTTokenSaleUpdated = await ethers.getContractFactory("EBTTokenSaleUpdated");
  const tokenSale = await EBTTokenSaleUpdated.deploy(
    ebtTokenAddress,
    usdtTokenAddress,
    pancakeRouterAddress,
    priceFeedAddress
  );
  
  await tokenSale.deployed();
  
  console.log("EBTTokenSaleUpdated contract deployed to:", tokenSale.address);
  console.log("Using EBT token at:", ebtTokenAddress);
  
  // Add verification information
  console.log("\nTo verify the contract on BSCScan:");
  console.log(`npx hardhat verify --network bsc ${tokenSale.address} ${ebtTokenAddress} ${usdtTokenAddress} ${pancakeRouterAddress} ${priceFeedAddress}`);
}

main()
  .then(() => process.exit(0))
  .catch((error) => {
    console.error(error);
    process.exit(1);
  });
