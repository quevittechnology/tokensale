// Script to check contract verification status
const { ethers } = require("hardhat");
const axios = require("axios");
require("dotenv").config();

async function main() {
  const bscscanApiKey = process.env.BSCSCAN_API_KEY;
  const contractAddress = "0xe2ef291fC99EF3fBf5918a52e85C1DcA7ac0744a";
  
  console.log("Checking verification status for contract:", contractAddress);
  
  try {
    const url = `https://api-testnet.bscscan.com/api?module=contract&action=getabi&address=${contractAddress}&apikey=${bscscanApiKey}`;
    const response = await axios.get(url);
    
    if (response.data.status === "1") {
      console.log("✅ Contract is verified on BSCScan");
      console.log("View at: https://testnet.bscscan.com/address/" + contractAddress + "#code");
    } else {
      console.log("❌ Contract is not verified on BSCScan");
      console.log("Response:", response.data);
      console.log("You may need to run verification again with:");
      console.log(`npx hardhat verify --network bscTestnet ${contractAddress} "0x55d398326f99059fF775485246999027B3197955" "0x10ED43C718714eb63d5aA57B78B54704E256024E" "0x0567F2323251f0Aab15c8dFb1967E4e8A7D42aeE"`);
    }
  } catch (error) {
    console.error("Error checking verification status:", error.message);
  }
}

main()
  .then(() => process.exit(0))
  .catch((error) => {
    console.error(error);
    process.exit(1);
  });