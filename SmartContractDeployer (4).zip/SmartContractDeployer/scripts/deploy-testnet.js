// Specialized deployment script for testnet with shorter timeouts
const hre = require("hardhat");
require("dotenv").config();

async function main() {
  const [deployer] = await ethers.getSigners();
  console.log("Deploying contracts with the account:", deployer.address);
  console.log("Account balance:", (await deployer.getBalance()).toString());
  
  // Get environment variables
  const usdtAddress = process.env.USDT_ADDRESS || "0x55d398326f99059fF775485246999027B3197955"; // BSC Mainnet USDT
  const pancakeRouterAddress = process.env.PANCAKE_ROUTER_ADDRESS || "0x10ED43C718714eb63d5aA57B78B54704E256024E"; // PancakeSwap Router
  const bnbUsdPriceFeed = process.env.CHAINLINK_BNBUSD_PRICEFEED || "0x0567F2323251f0Aab15c8dFb1967E4e8A7D42aeE"; // Chainlink BNB/USD Price Feed

  console.log("Deploying EBTToken to testnet...");
  console.log(`Using USDT address: ${usdtAddress}`);
  console.log(`Using PancakeSwap Router address: ${pancakeRouterAddress}`);
  console.log(`Using BNB/USD Price Feed address: ${bnbUsdPriceFeed}`);
  
  // Use different gas settings for testnet deployment
  const overrides = {
    gasLimit: 6000000,
    gasPrice: ethers.utils.parseUnits("10", "gwei"),
  };
  
  const EBTToken = await ethers.getContractFactory("EBTToken");
  console.log("Deploying contract...");
  const ebtToken = await EBTToken.deploy(
    usdtAddress,
    pancakeRouterAddress,
    bnbUsdPriceFeed,
    overrides
  );

  console.log("Contract deployment transaction sent!");
  console.log("Transaction hash:", ebtToken.deployTransaction.hash);
  console.log("Please check the transaction on BSCScan:");
  console.log(`https://testnet.bscscan.com/tx/${ebtToken.deployTransaction.hash}`);
  
  console.log("\nWaiting for one confirmation...");
  await ebtToken.deployTransaction.wait(1);
  
  console.log(`\nEBTToken deployed to: ${ebtToken.address}`);
  console.log(`View the contract on BSCScan: https://testnet.bscscan.com/address/${ebtToken.address}`);
  
  console.log("\nDeployment completed! You can now interact with the contract at:");
  console.log(ebtToken.address);
  
  // Skip verification in this script to avoid timeout
  console.log("\nTo verify the contract, run:");
  console.log(`npx hardhat verify --network bscTestnet ${ebtToken.address} "${usdtAddress}" "${pancakeRouterAddress}" "${bnbUsdPriceFeed}"`);
}

main()
  .then(() => process.exit(0))
  .catch((error) => {
    console.error(error);
    process.exit(1);
  });