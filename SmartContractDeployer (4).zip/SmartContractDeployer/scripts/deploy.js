// We require the Hardhat Runtime Environment explicitly here. This is optional
// but useful for running the script in a standalone fashion through `node <script>`.
const hre = require("hardhat");
require("dotenv").config();

async function main() {
  const [deployer] = await ethers.getSigners();
  console.log("Deploying contracts with the account:", deployer.address);
  
  // Get environment variables
  const usdtAddress = process.env.USDT_ADDRESS || "0x55d398326f99059fF775485246999027B3197955"; // BSC Mainnet USDT
  const pancakeRouterAddress = process.env.PANCAKE_ROUTER_ADDRESS || "0x10ED43C718714eb63d5aA57B78B54704E256024E"; // PancakeSwap Router
  const bnbUsdPriceFeed = process.env.CHAINLINK_BNBUSD_PRICEFEED || "0x0567F2323251f0Aab15c8dFb1967E4e8A7D42aeE"; // Chainlink BNB/USD Price Feed

  let ebtTokenAddress;
  
  // Check if we are on a testnet to deploy mocks
  const network = hre.network.name;
  console.log(`Deploying to network: ${network}`);
  
  if (network === "hardhat" || network === "localhost") {
    // Deploy mock dependencies for testing
    console.log("Deploying mock USDT...");
    const MockERC20 = await ethers.getContractFactory("MockERC20");
    const mockUsdt = await MockERC20.deploy(
      "Mock USDT", 
      "mUSDT", 
      ethers.utils.parseEther("1000000") // 1 million USDT
    );
    await mockUsdt.deployed();
    console.log("Mock USDT deployed to:", mockUsdt.address);

    console.log("Deploying mock price feed...");
    const MockChainlinkPriceFeed = await ethers.getContractFactory("MockChainlinkPriceFeed");
    const mockPriceFeed = await MockChainlinkPriceFeed.deploy(
      "30000000000", // $300 with 8 decimals
      8 // 8 decimals
    );
    await mockPriceFeed.deployed();
    console.log("Mock price feed deployed to:", mockPriceFeed.address);

    console.log("Deploying mock PancakeSwap router...");
    const MockUniswapV2Router = await ethers.getContractFactory("MockUniswapV2Router");
    const mockRouter = await MockUniswapV2Router.deploy(
      "0x0000000000000000000000000000000000000000", // Fake factory address
      "0x0000000000000000000000000000000000000000"  // Fake WETH address
    );
    await mockRouter.deployed();
    console.log("Mock PancakeSwap router deployed to:", mockRouter.address);

    // Deploy the main EBT Token with mock addresses
    console.log("Deploying EBTToken...");
    const EBTToken = await ethers.getContractFactory("EBTToken");
    const ebtToken = await EBTToken.deploy(
      mockUsdt.address,
      mockRouter.address,
      mockPriceFeed.address
    );

    await ebtToken.deployed();
    ebtTokenAddress = ebtToken.address;
    console.log("EBTToken deployed to:", ebtTokenAddress);
  } else {
    // Deploy to testnet or mainnet with real addresses
    console.log("Deploying EBTToken to production network...");
    console.log(`Using USDT address: ${usdtAddress}`);
    console.log(`Using PancakeSwap Router address: ${pancakeRouterAddress}`);
    console.log(`Using BNB/USD Price Feed address: ${bnbUsdPriceFeed}`);
    
    const EBTToken = await ethers.getContractFactory("EBTToken");
    const ebtToken = await EBTToken.deploy(
      usdtAddress,
      pancakeRouterAddress,
      bnbUsdPriceFeed
    );

    await ebtToken.deployed();
    ebtTokenAddress = ebtToken.address;
    console.log("EBTToken deployed to:", ebtTokenAddress);
  }

  // Optional: deploy security example for reference
  if (network === "hardhat" || network === "localhost") {
    console.log("Deploying SecurityEnhancements example...");
    const SecurityEnhancements = await ethers.getContractFactory("SecurityEnhancements");
    const securityEnhancements = await SecurityEnhancements.deploy();
    await securityEnhancements.deployed();
    console.log("SecurityEnhancements deployed to:", securityEnhancements.address);
  }
  
  // Log deployment information
  console.log("\n----- Deployment Summary -----");
  console.log(`Network: ${network}`);
  console.log(`EBTToken address: ${ebtTokenAddress}`);
  console.log("------------------------------\n");
  
  // If on a testnet or mainnet, wait for confirmation and verify
  if (network !== "hardhat" && network !== "localhost") {
    console.log("Waiting for block confirmations...");
    await ebtToken.deployTransaction.wait(5); // Wait for 5 confirmations
    
    // Verify the contract on BSCScan/Etherscan
    console.log("Verifying contract on explorer...");
    try {
      await hre.run("verify:verify", {
        address: ebtTokenAddress,
        constructorArguments: [
          usdtAddress,
          pancakeRouterAddress,
          bnbUsdPriceFeed
        ],
      });
      console.log("Contract verification completed!");
    } catch (error) {
      console.error("Error verifying contract:", error);
    }
  }
  
  console.log("Deployment completed successfully!");
}

// We recommend this pattern to be able to use async/await everywhere
// and properly handle errors.
main()
  .then(() => process.exit(0))
  .catch((error) => {
    console.error(error);
    process.exit(1);
  });
