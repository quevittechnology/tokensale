// Basic script to check ERC-20 functionality
const { ethers } = require("hardhat");

async function main() {
  // Contract address on BSC Testnet
  const contractAddress = "0xe2ef291fC99EF3fBf5918a52e85C1DcA7ac0744a";
  
  // Connect to BSC Testnet
  const provider = new ethers.providers.JsonRpcProvider("https://data-seed-prebsc-1-s1.binance.org:8545");
  
  // Simple ERC-20 ABI for basic functions
  const erc20Abi = [
    "function name() view returns (string)",
    "function symbol() view returns (string)",
    "function decimals() view returns (uint8)",
    "function totalSupply() view returns (uint256)",
    "function balanceOf(address) view returns (uint256)",
    "function owner() view returns (address)"
  ];
  
  // Connect to the contract
  const contract = new ethers.Contract(contractAddress, erc20Abi, provider);
  
  console.log("=== EBT Pay Token Basic Information ===");
  console.log(`Contract Address: ${contractAddress}`);
  console.log(`View on BSCScan: https://testnet.bscscan.com/address/${contractAddress}`);
  
  try {
    // Basic token information
    const name = await contract.name();
    const symbol = await contract.symbol();
    const decimals = await contract.decimals();
    const totalSupply = await contract.totalSupply();
    const formattedSupply = ethers.utils.formatUnits(totalSupply, decimals);
    
    console.log("\n=== Token Details ===");
    console.log(`Name: ${name}`);
    console.log(`Symbol: ${symbol}`);
    console.log(`Decimals: ${decimals}`);
    console.log(`Total Supply: ${formattedSupply} ${symbol}`);
    
    // Owner information
    try {
      const owner = await contract.owner();
      console.log(`\nContract Owner: ${owner}`);
    } catch (error) {
      console.log(`\nError retrieving owner: ${error.message}`);
    }
    
    // Check contract code
    const code = await provider.getCode(contractAddress);
    console.log(`\nContract has code: ${code.length > 2}`); // "0x" if no code
    console.log(`Code size: ${(code.length - 2) / 2} bytes`);
    
    // Check verification status
    console.log("\n=== Contract Verification Status ===");
    console.log("Check if contract is verified at:");
    console.log(`https://testnet.bscscan.com/address/${contractAddress}#code`);
    
  } catch (error) {
    console.error("Error checking contract details:", error);
  }
}

main()
  .then(() => process.exit(0))
  .catch((error) => {
    console.error(error);
    process.exit(1);
  });