import React, { useState, useEffect } from 'react';
import { Card, Form, Button, Row, Col, Table, Alert, Tabs, Tab } from 'react-bootstrap';
import { toast } from 'react-toastify';
import { 
  getEBTContract, 
  getSigner, 
  formatAmount, 
  parseAmount,
  isValidAddress
} from '../utils/web3';

const OWNER_ADDRESS = '0x1C040239180eEfc44f1F85996C8EC7833dD477a8';

const AdminPanel = ({ walletAddress }) => {
  const [isOwner, setIsOwner] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [activeTab, setActiveTab] = useState('presale');

  // Presale phase state
  const [phaseData, setPhaseData] = useState([
    { id: 0, startTime: '', duration: '', active: false, tokensAvailable: '0' },
    { id: 1, startTime: '', duration: '', active: false, tokensAvailable: '0' },
    { id: 2, startTime: '', duration: '', active: false, tokensAvailable: '0' },
    { id: 3, startTime: '', duration: '', active: false, tokensAvailable: '0' }
  ]);

  // Airdrop state
  const [airdropAddress, setAirdropAddress] = useState('');
  const [airdropAmount, setAirdropAmount] = useState('');
  
  // Admin address state
  const [newAdminAddress, setNewAdminAddress] = useState('');

  useEffect(() => {
    const checkPermissions = async () => {
      if (!walletAddress) {
        setLoading(false);
        return;
      }

      try {
        const contract = await getEBTContract();
        const owner = await contract.owner();
        const admin = await contract.admin();
        
        setIsOwner(walletAddress.toLowerCase() === owner.toLowerCase());
        setIsAdmin(walletAddress.toLowerCase() === admin.toLowerCase() || walletAddress.toLowerCase() === owner.toLowerCase());
        
        // Fetch phase data
        const updatedPhaseData = [...phaseData];
        for (let i = 0; i < 4; i++) {
          const phase = await contract.presalePhases(i);
          updatedPhaseData[i] = {
            id: i,
            startTime: phase.startTime.toString(),
            duration: phase.endTime.sub(phase.startTime).toString(),
            active: phase.active,
            tokensAvailable: formatAmount(phase.tokensAvailable),
          };
        }
        setPhaseData(updatedPhaseData);
        
        setLoading(false);
      } catch (error) {
        console.error('Error checking admin status:', error);
        setError('Failed to check administrative permissions');
        setLoading(false);
      }
    };

    checkPermissions();
  }, [walletAddress]);

  const handlePhaseActivation = async (phaseId) => {
    if (!isOwner) return;
    
    const phase = phaseData[phaseId];
    if (!phase.startTime || !phase.duration) {
      toast.error('Please set start time and duration');
      return;
    }
    
    try {
      setLoading(true);
      const contract = await getEBTContract(await getSigner());
      
      // Convert times to seconds
      const startTime = Math.floor(new Date(phase.startTime).getTime() / 1000);
      const duration = parseInt(phase.duration) * 3600; // Convert hours to seconds
      
      const tx = await contract.activatePhase(phaseId, startTime, duration);
      await tx.wait();
      
      // Update phase data
      const updatedPhaseData = [...phaseData];
      updatedPhaseData[phaseId].active = true;
      setPhaseData(updatedPhaseData);
      
      toast.success(`Phase ${phaseId + 1} activated successfully`);
    } catch (error) {
      console.error('Error activating phase:', error);
      toast.error('Failed to activate phase');
    } finally {
      setLoading(false);
    }
  };

  const handlePhaseDeactivation = async (phaseId) => {
    if (!isOwner) return;
    
    try {
      setLoading(true);
      const contract = await getEBTContract(await getSigner());
      
      const tx = await contract.deactivatePhase(phaseId);
      await tx.wait();
      
      // Update phase data
      const updatedPhaseData = [...phaseData];
      updatedPhaseData[phaseId].active = false;
      setPhaseData(updatedPhaseData);
      
      toast.success(`Phase ${phaseId + 1} deactivated successfully`);
    } catch (error) {
      console.error('Error deactivating phase:', error);
      toast.error('Failed to deactivate phase');
    } finally {
      setLoading(false);
    }
  };

  const handleSetAirdrop = async () => {
    if (!isAdmin || !airdropAddress || !airdropAmount) return;
    
    if (!isValidAddress(airdropAddress)) {
      toast.error('Invalid wallet address');
      return;
    }
    
    try {
      setLoading(true);
      const contract = await getEBTContract(await getSigner());
      
      const amount = parseAmount(airdropAmount);
      const tx = await contract.setAirdrop(airdropAddress, amount);
      await tx.wait();
      
      toast.success('Airdrop set successfully');
      
      // Clear form
      setAirdropAddress('');
      setAirdropAmount('');
    } catch (error) {
      console.error('Error setting airdrop:', error);
      toast.error('Failed to set airdrop');
    } finally {
      setLoading(false);
    }
  };

  const handleChangeAdmin = async () => {
    if (!isOwner || !newAdminAddress) return;
    
    if (!isValidAddress(newAdminAddress)) {
      toast.error('Invalid wallet address');
      return;
    }
    
    try {
      setLoading(true);
      const contract = await getEBTContract(await getSigner());
      
      const tx = await contract.setAdmin(newAdminAddress);
      await tx.wait();
      
      toast.success('Admin changed successfully');
      
      // Clear form
      setNewAdminAddress('');
    } catch (error) {
      console.error('Error changing admin:', error);
      toast.error('Failed to change admin');
    } finally {
      setLoading(false);
    }
  };

  const handlePhaseInputChange = (phaseId, field, value) => {
    const updatedPhaseData = [...phaseData];
    updatedPhaseData[phaseId][field] = value;
    setPhaseData(updatedPhaseData);
  };

  if (loading) {
    return (
      <Card className="mb-4">
        <Card.Header>Admin Panel</Card.Header>
        <Card.Body className="text-center">
          <div className="loader"></div>
          <p>Loading administrative functions...</p>
        </Card.Body>
      </Card>
    );
  }

  if (!walletAddress) {
    return (
      <Card className="mb-4">
        <Card.Header>Admin Panel</Card.Header>
        <Card.Body>
          <p className="text-center">Please connect your wallet to access administrative functions</p>
        </Card.Body>
      </Card>
    );
  }

  if (!isAdmin && !isOwner) {
    return (
      <Card className="mb-4">
        <Card.Header>Admin Panel</Card.Header>
        <Card.Body>
          <Alert variant="warning">
            You don't have administrative privileges. Only the contract owner ({OWNER_ADDRESS}) and designated admin can access these functions.
          </Alert>
        </Card.Body>
      </Card>
    );
  }

  return (
    <Card className="mb-4">
      <Card.Header>Admin Panel {isOwner ? '(Owner Access)' : '(Admin Access)'}</Card.Header>
      <Card.Body>
        {error && <Alert variant="danger">{error}</Alert>}
        
        <Tabs
          activeKey={activeTab}
          onSelect={(k) => setActiveTab(k)}
          className="mb-4"
        >
          <Tab eventKey="presale" title="Presale Management">
            <h5 className="section-title">Presale Phase Management</h5>
            <Table responsive bordered>
              <thead>
                <tr>
                  <th>Phase</th>
                  <th>Start Time</th>
                  <th>Duration (hours)</th>
                  <th>Status</th>
                  <th>Tokens Available</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {phaseData.map((phase) => (
                  <tr key={phase.id}>
                    <td>Phase {phase.id + 1}</td>
                    <td>
                      <Form.Control
                        type="datetime-local"
                        value={phase.startTime}
                        onChange={(e) => handlePhaseInputChange(phase.id, 'startTime', e.target.value)}
                        disabled={!isOwner || phase.active}
                      />
                    </td>
                    <td>
                      <Form.Control
                        type="number"
                        value={phase.duration}
                        onChange={(e) => handlePhaseInputChange(phase.id, 'duration', e.target.value)}
                        disabled={!isOwner || phase.active}
                        min="1"
                      />
                    </td>
                    <td>
                      <span className={`status-badge ${phase.active ? 'phase-active' : 'phase-upcoming'}`}>
                        {phase.active ? 'Active' : 'Inactive'}
                      </span>
                    </td>
                    <td>{phase.tokensAvailable} EBTP</td>
                    <td>
                      {isOwner && (
                        <>
                          {phase.active ? (
                            <Button
                              variant="danger"
                              size="sm"
                              onClick={() => handlePhaseDeactivation(phase.id)}
                              disabled={loading}
                            >
                              Deactivate
                            </Button>
                          ) : (
                            <Button
                              variant="success"
                              size="sm"
                              onClick={() => handlePhaseActivation(phase.id)}
                              disabled={loading || !phase.startTime || !phase.duration}
                            >
                              Activate
                            </Button>
                          )}
                        </>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </Table>
          </Tab>
          
          <Tab eventKey="airdrop" title="Airdrop Management">
            <h5 className="section-title">Set Airdrop Eligibility</h5>
            <Row>
              <Col md={6}>
                <Form.Group className="mb-3">
                  <Form.Label>Wallet Address</Form.Label>
                  <Form.Control
                    type="text"
                    placeholder="Enter wallet address"
                    value={airdropAddress}
                    onChange={(e) => setAirdropAddress(e.target.value)}
                  />
                </Form.Group>
              </Col>
              <Col md={6}>
                <Form.Group className="mb-3">
                  <Form.Label>Airdrop Amount (EBTP)</Form.Label>
                  <Form.Control
                    type="number"
                    placeholder="Enter token amount"
                    value={airdropAmount}
                    onChange={(e) => setAirdropAmount(e.target.value)}
                    min="0"
                    step="0.01"
                  />
                </Form.Group>
              </Col>
            </Row>
            <Button
              variant="primary"
              onClick={handleSetAirdrop}
              disabled={loading || !airdropAddress || !airdropAmount}
            >
              Set Airdrop
            </Button>
          </Tab>
          
          {isOwner && (
            <Tab eventKey="settings" title="Admin Settings">
              <h5 className="section-title">Change Admin Address</h5>
              <Row>
                <Col md={8}>
                  <Form.Group className="mb-3">
                    <Form.Label>New Admin Address</Form.Label>
                    <Form.Control
                      type="text"
                      placeholder="Enter new admin wallet address"
                      value={newAdminAddress}
                      onChange={(e) => setNewAdminAddress(e.target.value)}
                    />
                  </Form.Group>
                </Col>
                <Col md={4} className="d-flex align-items-end">
                  <Button
                    variant="warning"
                    onClick={handleChangeAdmin}
                    disabled={loading || !newAdminAddress}
                    className="mb-3 w-100"
                  >
                    Change Admin
                  </Button>
                </Col>
              </Row>
            </Tab>
          )}
        </Tabs>
      </Card.Body>
    </Card>
  );
};

export default AdminPanel;