import React, { useState, useEffect } from 'react';
import { Card, Button, Table, Row, Col } from 'react-bootstrap';
import { toast } from 'react-toastify';
import { 
  getEBTContract, 
  formatAmount, 
  generateReferralLink, 
  shortenAddress
} from '../utils/web3';

const ReferralInfo = ({ walletAddress }) => {
  const [referralLink, setReferralLink] = useState('');
  const [referralInfo, setReferralInfo] = useState({
    totalReferrals: 0,
    totalCommissionEarned: '0',
    totalAirdropCommissionEarned: '0',
    directReferrals: 0,
    levelStats: [],
    loading: true
  });

  useEffect(() => {
    if (walletAddress) {
      setReferralLink(generateReferralLink(walletAddress));
      fetchReferralInfo();
    }
  }, [walletAddress]);

  const fetchReferralInfo = async () => {
    if (!walletAddress) return;

    try {
      const contract = await getEBTContract();
      
      // Fetch referral data
      const [
        totalReferrals,
        totalCommissions,
        totalAirdropCommissions,
        directReferrals
      ] = await Promise.all([
        contract.getTotalReferrals(walletAddress),
        contract.getTotalCommissionEarned(walletAddress),
        contract.getTotalAirdropCommissionEarned(walletAddress),
        contract.getDirectReferrals(walletAddress)
      ]);

      // Fetch level stats
      const levelStats = [];
      for (let i = 1; i <= 5; i++) {
        const [count, commission, airdropCommission] = await Promise.all([
          contract.getReferralsCountAtLevel(walletAddress, i),
          contract.getCommissionEarnedAtLevel(walletAddress, i),
          contract.getAirdropCommissionEarnedAtLevel(walletAddress, i)
        ]);

        levelStats.push({
          level: i,
          count: count.toNumber(),
          commission: formatAmount(commission, 18),
          airdropCommission: formatAmount(airdropCommission)
        });
      }

      setReferralInfo({
        totalReferrals: totalReferrals.toNumber(),
        totalCommissionEarned: formatAmount(totalCommissions, 18),
        totalAirdropCommissionEarned: formatAmount(totalAirdropCommissions),
        directReferrals: directReferrals.toNumber(),
        levelStats,
        loading: false
      });
    } catch (error) {
      console.error('Error fetching referral info:', error);
      setReferralInfo(prev => ({ ...prev, loading: false }));
    }
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(referralLink)
      .then(() => {
        toast.success('Referral link copied to clipboard!');
      })
      .catch(err => {
        console.error('Failed to copy text: ', err);
        toast.error('Failed to copy referral link');
      });
  };

  if (!walletAddress) {
    return (
      <Card className="mb-4">
        <Card.Header>Referral Program</Card.Header>
        <Card.Body>
          <p className="text-center">Please connect your wallet to view your referral information</p>
        </Card.Body>
      </Card>
    );
  }

  if (referralInfo.loading) {
    return (
      <Card className="mb-4">
        <Card.Header>Referral Program</Card.Header>
        <Card.Body className="text-center">
          <div className="loader"></div>
          <p>Loading referral information...</p>
        </Card.Body>
      </Card>
    );
  }

  return (
    <Card className="mb-4">
      <Card.Header>Referral Program</Card.Header>
      <Card.Body>
        <Row>
          <Col md={6}>
            <div className="info-card">
              <h5 className="mb-3">Your Referral Link</h5>
              <div className="referral-link">
                {referralLink}
                <i 
                  className="bi bi-clipboard copy-button" 
                  onClick={copyToClipboard}
                  title="Copy to clipboard"
                >
                  📋
                </i>
              </div>
              <p className="mt-3">
                Share this link with others to earn referral commissions on their token purchases and airdrops!
              </p>
              <Button 
                variant="primary" 
                className="mt-2" 
                onClick={copyToClipboard}
              >
                Copy Link
              </Button>
            </div>
          </Col>
          
          <Col md={6}>
            <div className="info-card">
              <h5 className="mb-3">Referral Stats</h5>
              
              <div className="token-info">
                <span>Total Referrals:</span>
                <span>{referralInfo.totalReferrals}</span>
              </div>
              
              <div className="token-info">
                <span>Direct Referrals:</span>
                <span>{referralInfo.directReferrals}</span>
              </div>
              
              <div className="token-info">
                <span>Purchase Commission Earned:</span>
                <span>{referralInfo.totalCommissionEarned} USDT</span>
              </div>
              
              <div className="token-info">
                <span>Airdrop Commission Earned:</span>
                <span>{referralInfo.totalAirdropCommissionEarned} EBTP</span>
              </div>
            </div>
          </Col>
        </Row>
        
        <div className="mt-4">
          <h5 className="section-title">Commission Breakdown by Level</h5>
          <div className="table-responsive">
            <Table striped bordered hover>
              <thead>
                <tr>
                  <th>Level</th>
                  <th>Referrals</th>
                  <th>USDT Commission</th>
                  <th>EBTP Commission</th>
                </tr>
              </thead>
              <tbody>
                {referralInfo.levelStats.map(level => (
                  <tr key={level.level}>
                    <td>
                      <span className="level-badge">{level.level}</span>
                      Level {level.level}
                    </td>
                    <td>{level.count}</td>
                    <td>{level.commission} USDT</td>
                    <td>{level.airdropCommission} EBTP</td>
                  </tr>
                ))}
              </tbody>
            </Table>
          </div>
        </div>
      </Card.Body>
    </Card>
  );
};

export default ReferralInfo;