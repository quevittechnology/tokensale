import React, { useState, useEffect } from 'react';
import { Card, Form, Button, InputGroup, Alert, Tabs, Tab } from 'react-bootstrap';
import { toast } from 'react-toastify';
import { ethers } from 'ethers';
import { 
  getEBTContract, 
  getEBTTokenSaleContract,
  getUSDTContract, 
  getSigner,
  getProvider, 
  parseAmount, 
  formatAmount,
  getReferrerFromUrl,
  isValidAddress
} from '../utils/web3';

const TokenPurchase = ({ walletAddress }) => {
  const [purchaseMethod, setPurchaseMethod] = useState('usdt'); // 'usdt' or 'bnb'
  const [purchaseAmount, setPurchaseAmount] = useState('');
  const [tokensToBuy, setTokensToBuy] = useState('0');
  const [referrer, setReferrer] = useState('');
  const [tokenPrice, setTokenPrice] = useState('0');
  const [bnbPrice, setBnbPrice] = useState('0');
  const [bnbBalance, setBnbBalance] = useState('0');
  const [usdtBalance, setUsdtBalance] = useState('0');
  const [usdtAllowance, setUsdtAllowance] = useState('0');
  const [isApproving, setIsApproving] = useState(false);
  const [isPurchasing, setIsPurchasing] = useState(false);
  const [error, setError] = useState('');
  const [bonusPercentage, setBonusPercentage] = useState(0);

  useEffect(() => {
    // Check for referrer in URL
    const urlReferrer = getReferrerFromUrl();
    if (urlReferrer && isValidAddress(urlReferrer)) {
      setReferrer(urlReferrer);
    }
  }, []);

  useEffect(() => {
    const fetchTokenPrice = async () => {
      if (!walletAddress) return;
      
      try {
        const saleContract = await getEBTTokenSaleContract();
        
        // Try different possible function names for getting the token price
        let price;
        let bnbToUsdRate = 300; // Default estimation of BNB to USD rate (approximate)
        
        try {
          // Try the active phase's token price from the sale contract
          if (typeof saleContract.presalePhases === 'function') {
            // Try to get the first active phase
            for (let i = 0; i < 4; i++) {
              const phase = await saleContract.presalePhases(i);
              if (phase.active) {
                price = phase.tokenPrice;
                console.log(`Found active phase ${i} with price:`, formatAmount(price, 18));
                break;
              }
            }
          }
          
          // If no active phase found, use default price
          if (!price) {
            // Default price when no active phase is found
            price = ethers.utils.parseUnits('0.01', 18); // $0.01 per token as default
            console.log('No active phase found, using default price:', formatAmount(price, 18));
          }
          
          // For BNB price, use Chainlink price feed (which our sale contract uses internally)
          // Since we can't directly access the price feed result through the contract
          // we'll use an estimated conversion
          const estimatedBnbPrice = parseFloat(formatAmount(price, 18)) / bnbToUsdRate;
          setBnbPrice(estimatedBnbPrice.toFixed(18));
          console.log('Estimated BNB price per token:', estimatedBnbPrice.toFixed(18));
          
        } catch (e) {
          console.error('Error checking price functions:', e);
          
          // Manual price for demonstration
          price = ethers.utils.parseUnits('0.01', 18); // $0.01 per token as fallback
          console.log('Using fallback price:', formatAmount(price, 18));
          
          // Set an estimated BNB price based on current market rate
          const usdtPrice = 0.01; // default price
          const estimatedBnbPrice = usdtPrice / bnbToUsdRate;
          setBnbPrice(estimatedBnbPrice.toFixed(18));
        }
        
        if (price) {
          setTokenPrice(formatAmount(price, 18));
        } else {
          console.log('Could not determine token price');
          setTokenPrice('0.01'); // Fallback price for UI display
        }
      } catch (error) {
        console.error('Error fetching token price:', error);
        setTokenPrice('0.01'); // Fallback price for UI display
      }
    };

    const fetchBalances = async () => {
      if (!walletAddress) return;
      
      try {
        // Fetch USDT balance
        const usdtContract = await getUSDTContract();
        const usdtBal = await usdtContract.balanceOf(walletAddress);
        setUsdtBalance(formatAmount(usdtBal, 18));
        console.log('USDT balance:', formatAmount(usdtBal, 18));
        
        // Fetch BNB balance
        const provider = await getProvider();
        const bnbBal = await provider.getBalance(walletAddress);
        setBnbBalance(formatAmount(bnbBal, 18));
        console.log('BNB balance:', formatAmount(bnbBal, 18));
      } catch (error) {
        console.error('Error fetching balances:', error);
      }
    };
    
    fetchTokenPrice();
    fetchBalances();
  }, [walletAddress]);

  // Calculate tokens when purchase amount changes
  useEffect(() => {
    if (!purchaseAmount || parseFloat(purchaseAmount) === 0) {
      setTokensToBuy('0');
      setBonusPercentage(0);
      return;
    }

    try {
      const amount = parseFloat(purchaseAmount);
      let tokenAmount;
      
      // Use appropriate price based on purchase method
      if (purchaseMethod === 'usdt') {
        // For USDT: 1 USDT = 100 tokens (based on calculateTokenAmount function in contract)
        tokenAmount = amount * 100;
        
        // For bonus calculation (20% for purchases >= $100)
        if (amount >= 100) {
          setBonusPercentage(20);
          // Add 20% bonus tokens
          tokenAmount = tokenAmount * 1.2;
        } else {
          setBonusPercentage(0);
        }
      } else {
        // For BNB, use the price from contract or our fallback
        const bnbPriceVal = parseFloat(bnbPrice);
        
        if (!bnbPriceVal || bnbPriceVal === 0) {
          // Fallback calculation based on BNB price estimation
          // Assuming 1 BNB = 300 USD (approximate)
          // And 1 USDT = 100 tokens
          tokenAmount = amount * 300 * 100;
        } else {
          // If we have a proper BNB price, use it
          // This simulates the contract's calculateTokenAmountBNB function:
          // bnbAmount.mul(priceUSDTinBNB).mul(100).div(1e18)
          tokenAmount = amount / bnbPriceVal;
        }
        
        // For bonus calculation (20% for purchases >= 0.3 BNB which is ~$100)
        if (amount >= 0.3) {
          setBonusPercentage(20);
          // Add 20% bonus tokens
          tokenAmount = tokenAmount * 1.2;
        } else {
          setBonusPercentage(0);
        }
      }
      
      // Set the final token amount
      setTokensToBuy(tokenAmount.toFixed(2));
    } catch (error) {
      console.error('Error calculating tokens:', error);
      setTokensToBuy('0');
    }
  }, [purchaseAmount, tokenPrice, bnbPrice, purchaseMethod]);

  // Check USDT allowance
  useEffect(() => {
    const checkAllowance = async () => {
      if (!walletAddress || !purchaseAmount) return;

      try {
        const saleContract = await getEBTTokenSaleContract();
        const usdtContract = await getUSDTContract();
        const allowance = await usdtContract.allowance(walletAddress, saleContract.address);
        setUsdtAllowance(formatAmount(allowance, 18));
      } catch (error) {
        console.error('Error checking allowance:', error);
      }
    };

    checkAllowance();
  }, [walletAddress, purchaseAmount]);

  const handleApprove = async () => {
    if (!walletAddress || !purchaseAmount) return;
    
    setIsApproving(true);
    setError('');
    
    try {
      const saleContract = await getEBTTokenSaleContract();
      const usdtContract = await getUSDTContract(await getSigner());
      const amount = parseAmount(purchaseAmount, 18);
      
      const tx = await usdtContract.approve(saleContract.address, amount);
      toast.info('Approval transaction submitted. Please wait for confirmation.');
      
      await tx.wait();
      
      // Update allowance
      const allowance = await usdtContract.allowance(walletAddress, saleContract.address);
      setUsdtAllowance(formatAmount(allowance, 18));
      
      toast.success('USDT approved successfully!');
    } catch (error) {
      console.error('Error approving USDT:', error);
      setError(error.message || 'Failed to approve USDT');
      toast.error('Error approving USDT. Please try again.');
    } finally {
      setIsApproving(false);
    }
  };

  const handleUsdtPurchase = async () => {
    if (!walletAddress || !purchaseAmount) return;
    
    setIsPurchasing(true);
    setError('');
    
    try {
      const saleContract = await getEBTTokenSaleContract(await getSigner());
      const amount = parseAmount(purchaseAmount, 18);
      
      // Use default referrer if none provided
      const referrerAddress = referrer || '0x0000000000000000000000000000000000000000';
      
      console.log('Contract address:', saleContract.address);
      console.log('Purchase amount (USDT):', amount.toString());
      console.log('Referrer address:', referrerAddress);
      
      // Using the purchaseTokensWithUSDT function from our new sale contract
      const tx = await saleContract.purchaseTokensWithUSDT(amount, referrerAddress, {
        gasLimit: 500000 // Increase gas limit to ensure transaction has enough gas
      });
      
      toast.info('Purchase transaction submitted. Please wait for confirmation.');
      
      const receipt = await tx.wait();
      console.log('Transaction receipt:', receipt);
      
      toast.success('Tokens purchased successfully with USDT!');
      setPurchaseAmount('');
      setTokensToBuy('0');
      
      // Refresh balances
      const provider = await getProvider();
      const usdtContract = await getUSDTContract();
      const usdtBal = await usdtContract.balanceOf(walletAddress);
      setUsdtBalance(formatAmount(usdtBal, 18));
    } catch (error) {
      console.error('Error purchasing tokens with USDT:', error);
      handlePurchaseError(error);
    } finally {
      setIsPurchasing(false);
    }
  };
  
  const handleBnbPurchase = async () => {
    if (!walletAddress || !purchaseAmount) return;
    
    setIsPurchasing(true);
    setError('');
    
    try {
      const saleContract = await getEBTTokenSaleContract(await getSigner());
      const amount = parseAmount(purchaseAmount, 18);
      
      // Use default referrer if none provided
      const referrerAddress = referrer || '0x0000000000000000000000000000000000000000';
      
      console.log('Contract address:', saleContract.address);
      console.log('Purchase amount (BNB):', amount.toString());
      console.log('Referrer address:', referrerAddress);
      
      // Using the purchaseTokensWithBNB function from our new sale contract
      const tx = await saleContract.purchaseTokensWithBNB(referrerAddress, {
        value: amount,
        gasLimit: 500000
      });
      
      toast.info('Purchase transaction submitted. Please wait for confirmation.');
      console.log('Transaction hash:', tx.hash);
      
      const receipt = await tx.wait();
      console.log('Transaction receipt:', receipt);
      
      toast.success('Tokens purchased successfully with BNB!');
      setPurchaseAmount('');
      setTokensToBuy('0');
      
      // Refresh BNB balance
      const provider = await getProvider();
      const bnbBal = await provider.getBalance(walletAddress);
      setBnbBalance(formatAmount(bnbBal, 18));
    } catch (error) {
      console.error('Error purchasing tokens with BNB:', error);
      
      // Log detailed error information
      if (error.transaction) {
        console.log('Failed transaction data:', error.transaction);
      }
      if (error.receipt) {
        console.log('Failed transaction receipt:', error.receipt);
      }
      
      handlePurchaseError(error);
    } finally {
      setIsPurchasing(false);
    }
  };
  
  const handlePurchase = () => {
    if (purchaseMethod === 'usdt') {
      handleUsdtPurchase();
    } else {
      handleBnbPurchase();
    }
  };
  
  const handlePurchaseError = (error) => {
    // Enhanced error reporting
    let errorMessage = 'Failed to purchase tokens';
    
    if (error.reason) {
      errorMessage = `Contract error: ${error.reason}`;
    } else if (error.message) {
      // For user-friendly error message, clean up common errors
      if (error.message.includes('transaction failed')) {
        errorMessage = 'Transaction reverted by the contract. Check if the presale is active or if you meet the requirements.';
      } else if (error.message.includes('user rejected')) {
        errorMessage = 'Transaction rejected by user.';
      } else if (error.message.includes('insufficient funds')) {
        errorMessage = 'Insufficient funds for transaction. Please check your balance.';
      } else {
        errorMessage = error.message;
      }
    }
    
    setError(errorMessage);
    toast.error(errorMessage);
    
    // Check for the available functions on the contract
    try {
      const logContractFunctions = async () => {
        const saleContract = await getEBTTokenSaleContract();
        console.log('Available token sale contract functions:');
        for (const key in saleContract) {
          if (typeof saleContract[key] === 'function' && !key.startsWith('_')) {
            console.log(`- ${key}`);
          }
        }
      };
      logContractFunctions();
    } catch (e) {
      console.error('Error listing contract functions:', e);
    }
  };

  if (!walletAddress) {
    return (
      <Card className="mb-4">
        <Card.Header>Purchase Tokens</Card.Header>
        <Card.Body>
          <p className="text-center">Please connect your wallet to purchase tokens</p>
        </Card.Body>
      </Card>
    );
  }

  const needsApproval = parseFloat(purchaseAmount) > parseFloat(usdtAllowance);
  const insufficientBalance = parseFloat(purchaseAmount) > parseFloat(usdtBalance);

  const renderUsdtTab = () => {
    const insufficientBalance = parseFloat(purchaseAmount) > parseFloat(usdtBalance);
    const needsApproval = parseFloat(purchaseAmount) > parseFloat(usdtAllowance);
    
    return (
      <>
        <div className="wallet-balance mb-3" style={{ display: 'flex', justifyContent: 'space-between', padding: '10px', backgroundColor: '#f8f9fa', borderRadius: '5px' }}>
          <span><strong>USDT Balance:</strong></span>
          <span>{usdtBalance} USDT</span>
        </div>
        
        <Form.Group className="mb-3">
          <Form.Label>Amount to Spend (USDT)</Form.Label>
          <InputGroup>
            <Form.Control
              type="number"
              placeholder="Enter USDT amount"
              value={purchaseAmount}
              onChange={(e) => setPurchaseAmount(e.target.value)}
              min="0"
              step="0.01"
            />
            <InputGroup.Text>USDT</InputGroup.Text>
          </InputGroup>
          <Form.Text className="text-muted">
            Current price: ${tokenPrice} USDT per token
          </Form.Text>
        </Form.Group>
        
        {insufficientBalance ? (
          <Alert variant="warning">
            Insufficient USDT balance. You need {purchaseAmount} USDT but only have {usdtBalance} USDT.
          </Alert>
        ) : needsApproval ? (
          <Button
            variant="primary"
            onClick={handleApprove}
            disabled={isApproving || !purchaseAmount || parseFloat(purchaseAmount) <= 0}
            className="w-100"
          >
            {isApproving ? 'Approving...' : 'Approve USDT'}
          </Button>
        ) : (
          <Button
            variant="success"
            onClick={handlePurchase}
            disabled={isPurchasing || !purchaseAmount || parseFloat(purchaseAmount) <= 0}
            className="w-100"
          >
            {isPurchasing ? 'Processing...' : 'Purchase Tokens with USDT'}
          </Button>
        )}
      </>
    );
  };
  
  const renderBnbTab = () => {
    const insufficientBnbBalance = parseFloat(purchaseAmount) > parseFloat(bnbBalance);
    
    return (
      <>
        <div className="wallet-balance mb-3" style={{ display: 'flex', justifyContent: 'space-between', padding: '10px', backgroundColor: '#f8f9fa', borderRadius: '5px' }}>
          <span><strong>BNB Balance:</strong></span>
          <span>{bnbBalance} BNB</span>
        </div>
        
        <Form.Group className="mb-3">
          <Form.Label>Amount to Spend (BNB)</Form.Label>
          <InputGroup>
            <Form.Control
              type="number"
              placeholder="Enter BNB amount"
              value={purchaseAmount}
              onChange={(e) => setPurchaseAmount(e.target.value)}
              min="0"
              step="0.001"
            />
            <InputGroup.Text>BNB</InputGroup.Text>
          </InputGroup>
          <Form.Text className="text-muted">
            Current price: {bnbPrice} BNB per token
          </Form.Text>
        </Form.Group>
        
        {insufficientBnbBalance ? (
          <Alert variant="warning">
            Insufficient BNB balance. You need {purchaseAmount} BNB but only have {bnbBalance} BNB.
          </Alert>
        ) : (
          <Button
            variant="warning"
            onClick={handlePurchase}
            disabled={isPurchasing || !purchaseAmount || parseFloat(purchaseAmount) <= 0}
            className="w-100"
          >
            {isPurchasing ? 'Processing...' : 'Purchase Tokens with BNB'}
          </Button>
        )}
      </>
    );
  };

  return (
    <Card className="mb-4">
      <Card.Header>Purchase Tokens</Card.Header>
      <Card.Body>
        <Tabs
          activeKey={purchaseMethod}
          onSelect={(k) => {
            setPurchaseMethod(k);
            setPurchaseAmount('');
            setTokensToBuy('0');
            setError('');
          }}
          className="mb-3"
        >
          <Tab eventKey="usdt" title="Buy with USDT">
            {renderUsdtTab()}
          </Tab>
          <Tab eventKey="bnb" title="Buy with BNB">
            {renderBnbTab()}
          </Tab>
        </Tabs>

        <Form>
          <Form.Group className="mb-3">
            <Form.Label>Referrer Address (Optional)</Form.Label>
            <Form.Control
              type="text"
              placeholder="Enter referrer address"
              value={referrer}
              onChange={(e) => setReferrer(e.target.value)}
              disabled={getReferrerFromUrl() !== null}
            />
            {getReferrerFromUrl() && (
              <Form.Text className="text-muted">
                Referrer address detected from URL
              </Form.Text>
            )}
          </Form.Group>

          <div className="info-card mb-3" style={{ padding: '15px', backgroundColor: '#e8f4fd', borderRadius: '5px', border: '1px solid #c8e1fb' }}>
            <h6 style={{ fontWeight: 'bold', color: '#0056b3', marginBottom: '10px' }}>Purchase Summary</h6>
            <div className="token-info" style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8px' }}>
              <span>You will receive:</span>
              <span className="token-amount" style={{ fontWeight: 'bold', fontSize: '1.1rem' }}>{tokensToBuy} EBTP</span>
            </div>
            
            {bonusPercentage > 0 && (
              <div className="text-success mt-2" style={{ backgroundColor: '#d4edda', padding: '8px', borderRadius: '4px', textAlign: 'center' }}>
                <strong>+ {bonusPercentage}% Bonus!</strong> for purchasing $100 or more
              </div>
            )}
          </div>

          {error && <Alert variant="danger">{error}</Alert>}
        </Form>
      </Card.Body>
    </Card>
  );
};

export default TokenPurchase;