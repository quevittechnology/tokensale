import React from 'react';
import { Navbar, Nav, Container } from 'react-bootstrap';
import WalletConnect from './WalletConnect';

const Navigation = ({ walletAddress, setWalletAddress, activeTab, setActiveTab }) => {
  return (
    <Navbar expand="lg" className="navbar-custom mb-4">
      <Container>
        <Navbar.Brand href="#">EBT Pay (EBTP)</Navbar.Brand>
        <Navbar.Toggle aria-controls="basic-navbar-nav" />
        <Navbar.Collapse id="basic-navbar-nav">
          <Nav className="me-auto">
            <Nav.Link 
              className={activeTab === 'home' ? 'active-nav-link' : ''} 
              onClick={() => setActiveTab('home')}
            >
              Dashboard
            </Nav.Link>
            <Nav.Link 
              className={activeTab === 'purchase' ? 'active-nav-link' : ''} 
              onClick={() => setActiveTab('purchase')}
            >
              Buy Tokens
            </Nav.Link>
            <Nav.Link 
              className={activeTab === 'referral' ? 'active-nav-link' : ''} 
              onClick={() => setActiveTab('referral')}
            >
              Referral Program
            </Nav.Link>
            <Nav.Link 
              className={activeTab === 'vesting' ? 'active-nav-link' : ''} 
              onClick={() => setActiveTab('vesting')}
            >
              Affiliate Rewards
            </Nav.Link>
            <Nav.Link 
              className={activeTab === 'admin' ? 'active-nav-link' : ''} 
              onClick={() => setActiveTab('admin')}
            >
              Admin Panel
            </Nav.Link>
          </Nav>
          <WalletConnect 
            walletAddress={walletAddress} 
            setWalletAddress={setWalletAddress} 
          />
        </Navbar.Collapse>
      </Container>
    </Navbar>
  );
};

export default Navigation;