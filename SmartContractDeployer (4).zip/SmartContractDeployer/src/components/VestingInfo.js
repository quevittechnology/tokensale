import React, { useState, useEffect } from 'react';
import { Card, Table, Button, Spinner, Alert, ProgressBar } from 'react-bootstrap';
import { toast } from 'react-toastify';
import { 
  getUpdatedEBTTokenSaleContract,
  getSigner,
  formatAmount,
  EBT_TOKEN_SALE_UPDATED_ADDRESS
} from '../utils/web3';
import { ethers } from 'ethers';

const VestingInfo = ({ walletAddress }) => {
  const [loading, setLoading] = useState(true);
  const [claiming, setClaiming] = useState(false);
  const [vestingInfo, setVestingInfo] = useState(null);
  const [error, setError] = useState('');
  const [remainingTime, setRemainingTime] = useState(null);

  const loadVestingInfo = async () => {
    if (!walletAddress) {
      setLoading(false);
      return;
    }

    try {
      setLoading(true);
      setError('');
      
      const tokenSale = await getUpdatedEBTTokenSaleContract();
      
      // Get affiliate vesting info
      const hasVesting = await tokenSale.hasAffiliateVesting(walletAddress);
      
      if (hasVesting) {
        const vestingAmount = await tokenSale.getAffiliateVestingAmount(walletAddress);
        const vestingStart = await tokenSale.getAffiliateVestingStart(walletAddress);
        const vestingEnd = await tokenSale.getAffiliateVestingEnd(walletAddress);
        const claimedAmount = await tokenSale.getAffiliateClaimedAmount(walletAddress);
        const vestingDuration = vestingEnd.sub(vestingStart);
        const currentTime = Math.floor(Date.now() / 1000);
        const timeElapsed = currentTime - vestingStart.toNumber();
        const percentComplete = Math.min(100, (timeElapsed / vestingDuration.toNumber()) * 100);
        
        // Calculate claimable amount
        let claimableAmount = ethers.BigNumber.from(0);
        if (currentTime >= vestingStart.toNumber()) {
          const elapsedRatio = Math.min(1, timeElapsed / vestingDuration.toNumber());
          const totalVestedAmount = vestingAmount.mul(Math.floor(elapsedRatio * 1000000)).div(1000000);
          claimableAmount = totalVestedAmount.sub(claimedAmount);
        }
        
        // Calculate remaining time
        const remainingSeconds = vestingEnd.toNumber() - currentTime;
        if (remainingSeconds > 0) {
          const days = Math.floor(remainingSeconds / (60 * 60 * 24));
          const hours = Math.floor((remainingSeconds % (60 * 60 * 24)) / (60 * 60));
          const minutes = Math.floor((remainingSeconds % (60 * 60)) / 60);
          setRemainingTime({ days, hours, minutes });
        } else {
          setRemainingTime({ days: 0, hours: 0, minutes: 0 });
        }
        
        setVestingInfo({
          hasVesting: true,
          totalAmount: vestingAmount,
          vestingStart: new Date(vestingStart.toNumber() * 1000).toLocaleString(),
          vestingEnd: new Date(vestingEnd.toNumber() * 1000).toLocaleString(),
          claimedAmount,
          claimableAmount,
          percentComplete,
          vestingDuration: vestingDuration.toNumber()
        });
      } else {
        setVestingInfo({ hasVesting: false });
      }
      
      setLoading(false);
    } catch (err) {
      console.error("Error loading vesting info:", err);
      setError("Failed to load affiliate vesting information. Please try again.");
      setLoading(false);
    }
  };

  const handleClaim = async () => {
    if (!walletAddress || !vestingInfo || !vestingInfo.hasVesting || vestingInfo.claimableAmount.eq(0)) {
      return;
    }

    try {
      setClaiming(true);
      const signer = await getSigner();
      const tokenSale = await getUpdatedEBTTokenSaleContract(signer); // with signer
      
      const tx = await tokenSale.claimAffiliateVesting();
      const receipt = await tx.wait();
      
      if (receipt.status === 1) {
        toast.success("Successfully claimed vested tokens!");
        loadVestingInfo(); // Refresh the vesting info
      } else {
        toast.error("Transaction failed. Please try again.");
      }
      
      setClaiming(false);
    } catch (err) {
      console.error("Error claiming vested tokens:", err);
      toast.error(err.message || "Failed to claim vested tokens. Please try again.");
      setClaiming(false);
    }
  };

  useEffect(() => {
    loadVestingInfo();
    
    // Set up a timer to refresh the vesting info every minute
    const interval = setInterval(() => {
      if (walletAddress) {
        loadVestingInfo();
      }
    }, 60000);
    
    return () => clearInterval(interval);
  }, [walletAddress]);

  const renderVestingContent = () => {
    if (loading) {
      return (
        <div className="text-center my-5">
          <Spinner animation="border" variant="primary" />
          <p className="mt-3">Loading vesting information...</p>
        </div>
      );
    }

    if (error) {
      return (
        <Alert variant="danger" className="my-3">
          <Alert.Heading>Error</Alert.Heading>
          <p>{error}</p>
          <div className="d-flex justify-content-end">
            <Button 
              variant="outline-danger" 
              onClick={loadVestingInfo}
            >
              Try Again
            </Button>
          </div>
        </Alert>
      );
    }

    if (!vestingInfo) {
      return (
        <Alert variant="info" className="my-3">
          <p>Please connect your wallet to view your affiliate vesting information.</p>
        </Alert>
      );
    }

    if (!vestingInfo.hasVesting) {
      return (
        <Alert variant="info" className="my-3">
          <Alert.Heading>No Active Vesting</Alert.Heading>
          <p>
            You don't have any active affiliate vesting. Generate referral sales to qualify for
            affiliate rewards with a 5-year vesting period.
          </p>
        </Alert>
      );
    }

    return (
      <>
        <div className="mb-4">
          <h5>Vesting Progress</h5>
          <ProgressBar 
            now={vestingInfo.percentComplete} 
            label={`${Math.floor(vestingInfo.percentComplete)}%`}
            variant="success" 
            className="mb-2" 
          />
          
          {remainingTime && (
            <p className="text-muted mb-0">
              Time remaining: {remainingTime.days} days, {remainingTime.hours} hours, {remainingTime.minutes} minutes
            </p>
          )}
        </div>
        
        <Table striped bordered hover responsive className="mt-3">
          <tbody>
            <tr>
              <td>Total Vesting Amount</td>
              <td>{formatAmount(vestingInfo.totalAmount)} EBTP</td>
            </tr>
            <tr>
              <td>Vesting Start Date</td>
              <td>{vestingInfo.vestingStart}</td>
            </tr>
            <tr>
              <td>Vesting End Date</td>
              <td>{vestingInfo.vestingEnd}</td>
            </tr>
            <tr>
              <td>Claimed Amount</td>
              <td>{formatAmount(vestingInfo.claimedAmount)} EBTP</td>
            </tr>
            <tr>
              <td>Currently Claimable</td>
              <td>{formatAmount(vestingInfo.claimableAmount)} EBTP</td>
            </tr>
          </tbody>
        </Table>
        
        <div className="d-grid gap-2 mt-4">
          <Button 
            variant="primary" 
            size="lg" 
            onClick={handleClaim}
            disabled={claiming || vestingInfo.claimableAmount.eq(0)}
          >
            {claiming ? (
              <>
                <Spinner as="span" animation="border" size="sm" role="status" aria-hidden="true" />
                <span className="ms-2">Processing...</span>
              </>
            ) : (
              `Claim ${formatAmount(vestingInfo.claimableAmount)} EBTP Tokens`
            )}
          </Button>
        </div>
        
        <div className="mt-3">
          <small className="text-muted">
            Affiliate rewards are locked in a 5-year vesting contract with daily release.
            You can claim your available tokens at any time.
          </small>
        </div>
      </>
    );
  };

  return (
    <Card className="shadow mb-4">
      <Card.Header className="bg-primary text-white">
        <h4 className="mb-0">Affiliate Rewards Vesting</h4>
      </Card.Header>
      <Card.Body>
        <p className="mb-4">
          When you refer customers who purchase a total of $1000 worth of EBTP tokens, you qualify for a $100 equivalent
          reward in EBTP tokens. These reward tokens are locked in a 5-year vesting contract with daily release.
        </p>
        
        {renderVestingContent()}
        
        {vestingInfo && vestingInfo.hasVesting && (
          <div className="mt-4 pt-3 border-top">
            <h5>Contract Details</h5>
            <p className="mb-1">
              <strong>Token Sale Contract:</strong> <a 
                href={`https://testnet.bscscan.com/address/${EBT_TOKEN_SALE_UPDATED_ADDRESS}`}
                target="_blank"
                rel="noopener noreferrer"
              >
                {EBT_TOKEN_SALE_UPDATED_ADDRESS}
              </a>
            </p>
          </div>
        )}
      </Card.Body>
    </Card>
  );
};

export default VestingInfo;