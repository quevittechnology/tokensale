import React, { useState, useEffect } from 'react';
import { Button, Dropdown } from 'react-bootstrap';
import { connectWallet, disconnectWallet, shortenAddress } from '../utils/web3';

const WalletConnect = ({ onConnect, walletAddress, setWalletAddress }) => {
  const [isConnecting, setIsConnecting] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    // Check if wallet was previously connected
    const checkConnection = async () => {
      try {
        if (window.ethereum && window.ethereum.selectedAddress) {
          const address = window.ethereum.selectedAddress;
          setWalletAddress(address);
          if (onConnect) onConnect(address);
        }
      } catch (err) {
        console.error('Error checking wallet connection:', err);
      }
    };

    checkConnection();

    // Handle account changes
    if (window.ethereum) {
      window.ethereum.on('accountsChanged', (accounts) => {
        if (accounts.length > 0) {
          setWalletAddress(accounts[0]);
          if (onConnect) onConnect(accounts[0]);
        } else {
          setWalletAddress('');
        }
      });
    }
  }, [onConnect, setWalletAddress]);

  const [isDisconnecting, setIsDisconnecting] = useState(false);

  const handleConnect = async () => {
    setIsConnecting(true);
    setError('');

    try {
      const address = await connectWallet();
      setWalletAddress(address);
      if (onConnect) onConnect(address);
    } catch (err) {
      console.error('Error connecting wallet:', err);
      setError(err.message || 'Failed to connect wallet');
    } finally {
      setIsConnecting(false);
    }
  };

  const handleDisconnect = async () => {
    setIsDisconnecting(true);
    setError('');

    try {
      await disconnectWallet();
      // Clear wallet state
      setWalletAddress('');
      // Trigger any parent component updates
      if (onConnect) onConnect('');
    } catch (err) {
      console.error('Error disconnecting wallet:', err);
      setError(err.message || 'Failed to disconnect wallet');
    } finally {
      setIsDisconnecting(false);
    }
  };

  return (
    <div className="wallet-connect">
      {walletAddress ? (
        <Dropdown>
          <Dropdown.Toggle variant="outline-light" id="wallet-dropdown">
            Connected: {shortenAddress(walletAddress)}
          </Dropdown.Toggle>

          <Dropdown.Menu>
            <Dropdown.Item as="button" onClick={() => {
              // Copy address to clipboard
              navigator.clipboard.writeText(walletAddress);
              alert('Address copied to clipboard!');
            }}>
              Copy Address
            </Dropdown.Item>
            <Dropdown.Item as="button" 
              onClick={handleDisconnect}
              disabled={isDisconnecting}
            >
              {isDisconnecting ? 'Disconnecting...' : 'Disconnect Wallet'}
            </Dropdown.Item>
          </Dropdown.Menu>
        </Dropdown>
      ) : (
        <Button 
          variant="primary" 
          onClick={handleConnect} 
          disabled={isConnecting}
          className="btn-connect"
        >
          {isConnecting ? 'Connecting...' : 'Connect Wallet'}
        </Button>
      )}
      
      {error && <div className="text-danger mt-2">{error}</div>}
    </div>
  );
};

export default WalletConnect;