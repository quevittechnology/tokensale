import React, { useState, useEffect } from 'react';
import { Card, Row, Col } from 'react-bootstrap';
import { getEBTContract, getProvider, formatAmount } from '../utils/web3';

const TokenInfo = ({ walletAddress }) => {
  const [tokenInfo, setTokenInfo] = useState({
    name: '',
    symbol: '',
    totalSupply: '',
    balance: '',
    decimals: 0,
    currentPhase: 0,
    phaseTokensRemaining: '',
    tokenPrice: '',
    isLoading: true,
  });

  useEffect(() => {
    const fetchTokenInfo = async () => {
      if (!walletAddress) {
        return;
      }

      try {
        const provider = await getProvider();
        const contract = await getEBTContract(provider);

        // Fetch basic token info
        const [
          name,
          symbol,
          totalSupply,
          decimals,
          balance,
          currentPhase,
          phaseTokensRemaining,
          tokenPrice
        ] = await Promise.all([
          contract.name(),
          contract.symbol(),
          contract.totalSupply(),
          contract.decimals(),
          contract.balanceOf(walletAddress),
          contract.getCurrentPhase(),
          contract.getPhaseTokensRemaining(),
          contract.getTokenPrice()
        ]);

        setTokenInfo({
          name,
          symbol,
          totalSupply: formatAmount(totalSupply),
          balance: formatAmount(balance),
          decimals: decimals.toNumber(),
          currentPhase: currentPhase.toNumber(),
          phaseTokensRemaining: formatAmount(phaseTokensRemaining),
          tokenPrice: formatAmount(tokenPrice, 18),
          isLoading: false,
        });
      } catch (error) {
        console.error('Error fetching token info:', error);
        setTokenInfo(prev => ({ ...prev, isLoading: false }));
      }
    };

    fetchTokenInfo();
  }, [walletAddress]);

  if (!walletAddress) {
    return (
      <Card className="mb-4">
        <Card.Header>Token Information</Card.Header>
        <Card.Body>
          <p className="text-center">Please connect your wallet to view token information</p>
        </Card.Body>
      </Card>
    );
  }

  if (tokenInfo.isLoading) {
    return (
      <Card className="mb-4">
        <Card.Header>Token Information</Card.Header>
        <Card.Body className="text-center">
          <div className="loader"></div>
          <p>Loading token information...</p>
        </Card.Body>
      </Card>
    );
  }

  return (
    <Card className="mb-4">
      <Card.Header>Token Information</Card.Header>
      <Card.Body>
        <Row>
          <Col md={6}>
            <div className="info-card">
              <h5 className="mb-3">{tokenInfo.name} ({tokenInfo.symbol})</h5>
              
              <div className="token-info">
                <span>Your Balance:</span>
                <span className="token-amount">{tokenInfo.balance} {tokenInfo.symbol}</span>
              </div>
              
              <div className="token-info">
                <span>Total Supply:</span>
                <span>{tokenInfo.totalSupply} {tokenInfo.symbol}</span>
              </div>
              
              <div className="token-info">
                <span>Decimals:</span>
                <span>{tokenInfo.decimals}</span>
              </div>
            </div>
          </Col>
          
          <Col md={6}>
            <div className="info-card">
              <h5 className="mb-3">Presale Information</h5>
              
              <div className="token-info">
                <span>Current Phase:</span>
                <span>Phase {tokenInfo.currentPhase}</span>
              </div>
              
              <div className="token-info">
                <span>Tokens Remaining:</span>
                <span>{tokenInfo.phaseTokensRemaining} {tokenInfo.symbol}</span>
              </div>
              
              <div className="token-info">
                <span>Token Price:</span>
                <span>${tokenInfo.tokenPrice} USDT</span>
              </div>
              
              <div className="token-info mt-2">
                <span>Presale Status:</span>
                <span className="status-badge phase-active">Active</span>
              </div>
            </div>
          </Col>
        </Row>
      </Card.Body>
    </Card>
  );
};

export default TokenInfo;