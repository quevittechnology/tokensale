import React, { useState, useEffect } from 'react';
import { Container, Row, Col, Alert } from 'react-bootstrap';
import { ToastContainer } from 'react-toastify';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'react-toastify/dist/ReactToastify.css';
import './styles/App.css';

import Navigation from './components/Navigation';
import TokenInfo from './components/TokenInfo';
import TokenPurchase from './components/TokenPurchase';
import ReferralInfo from './components/ReferralInfo';
import VestingInfo from './components/VestingInfo';
import AdminPanel from './components/AdminPanel';

function App() {
  const [walletAddress, setWalletAddress] = useState('');
  const [activeTab, setActiveTab] = useState('home');
  const [networkError, setNetworkError] = useState(false);

  useEffect(() => {
    // Check if on BSC Testnet
    const checkNetwork = async () => {
      if (window.ethereum) {
        const chainId = await window.ethereum.request({ method: 'eth_chainId' });
        setNetworkError(chainId !== '0x61'); // BSC Testnet chain ID
        
        // Listen for chain changes
        window.ethereum.on('chainChanged', (newChainId) => {
          setNetworkError(newChainId !== '0x61');
          window.location.reload(); // Recommended by MetaMask
        });
      }
    };
    
    checkNetwork();
  }, []);

  const renderContent = () => {
    switch (activeTab) {
      case 'purchase':
        return <TokenPurchase walletAddress={walletAddress} />;
      case 'referral':
        return <ReferralInfo walletAddress={walletAddress} />;
      case 'vesting':
        return <VestingInfo walletAddress={walletAddress} />;
      case 'admin':
        return <AdminPanel walletAddress={walletAddress} />;
      case 'home':
      default:
        return (
          <>
            <TokenInfo walletAddress={walletAddress} />
            <TokenPurchase walletAddress={walletAddress} />
            <ReferralInfo walletAddress={walletAddress} />
          </>
        );
    }
  };

  return (
    <div className="app-container">
      <ToastContainer position="top-right" autoClose={5000} />
      
      <Navigation 
        walletAddress={walletAddress} 
        setWalletAddress={setWalletAddress} 
        activeTab={activeTab}
        setActiveTab={setActiveTab}
      />
      
      <Container>
        {networkError && walletAddress && (
          <Alert variant="danger" className="mb-4">
            <strong>Wrong Network Detected!</strong> Please switch to BSC Testnet in your wallet to use this application.
          </Alert>
        )}
        
        {!walletAddress && (
          <Alert variant="warning" className="mb-4">
            <strong>Wallet Not Connected!</strong> Please connect your wallet to use the application's full features.
          </Alert>
        )}
        
        <Row>
          <Col>
            {renderContent()}
          </Col>
        </Row>
        
        <footer className="text-center text-white mt-4 pb-3">
          <p>EBT Pay (EBTP) - Token Presale Platform</p>
          <p className="small">© 2023 All Rights Reserved</p>
        </footer>
      </Container>
    </div>
  );
}

export default App;