import { ethers } from 'ethers';
import detectEthereumProvider from '@metamask/detect-provider';
import EBTTokenABI from '../abis/EBTToken.json';
import EBTTokenSaleABI from '../abis/EBTTokenSale.json';
import EBTTokenSaleUpdatedABI from '../abis/EBTTokenSaleUpdated.json';
import ERC20ABI from '../abis/ERC20.json';

// Contract addresses
export const EBT_TOKEN_ADDRESS = '0xCA798C521acDec75D57872BA03c1e7f789e1C4Ca'; // Updated to the existing token address
export const EBT_TOKEN_SALE_ADDRESS = '0x0000000000000000000000000000000000000000'; // This will be updated after deployment
export const EBT_TOKEN_SALE_UPDATED_ADDRESS = '0x0000000000000000000000000000000000000000'; // This will be updated after new deployment
export const USDT_ADDRESS = '0x55d398326f99059fF775485246999027B3197955'; // Mainnet USDT
export const USDT_TESTNET_ADDRESS = '0x337610d27c682E347C9cD60BD4b3b107C9d34dDd'; // Testnet USDT

// BSC Testnet network configuration
export const BSC_TESTNET_CONFIG = {
  chainId: '0x61',
  chainName: 'BSC Testnet',
  nativeCurrency: {
    name: 'tBNB',
    symbol: 'tBNB',
    decimals: 18,
  },
  rpcUrls: ['https://data-seed-prebsc-1-s1.binance.org:8545/'],
  blockExplorerUrls: ['https://testnet.bscscan.com/'],
};

// Get provider and signer
export const getProvider = async () => {
  const provider = await detectEthereumProvider();
  
  if (provider) {
    return new ethers.providers.Web3Provider(provider);
  } else {
    throw new Error('Please install MetaMask!');
  }
};

// Get signer
export const getSigner = async () => {
  const provider = await getProvider();
  return provider.getSigner();
};

// Get contracts
export const getEBTContract = async (signerOrProvider) => {
  if (!signerOrProvider) {
    signerOrProvider = await getSigner();
  }
  return new ethers.Contract(EBT_TOKEN_ADDRESS, EBTTokenABI, signerOrProvider);
};

export const getUSDTContract = async (signerOrProvider) => {
  if (!signerOrProvider) {
    signerOrProvider = await getSigner();
  }
  
  // Use testnet or mainnet USDT address based on current network
  const provider = await detectEthereumProvider();
  const chainId = await provider.request({ method: 'eth_chainId' });
  const usdtAddress = chainId === BSC_TESTNET_CONFIG.chainId ? USDT_TESTNET_ADDRESS : USDT_ADDRESS;
  
  return new ethers.Contract(usdtAddress, ERC20ABI, signerOrProvider);
};

export const getEBTTokenSaleContract = async (signerOrProvider) => {
  if (!signerOrProvider) {
    signerOrProvider = await getSigner();
  }
  return new ethers.Contract(EBT_TOKEN_SALE_ADDRESS, EBTTokenSaleABI, signerOrProvider);
};

export const getUpdatedEBTTokenSaleContract = async (signerOrProvider) => {
  if (!signerOrProvider) {
    signerOrProvider = await getSigner();
  }
  return new ethers.Contract(EBT_TOKEN_SALE_UPDATED_ADDRESS, EBTTokenSaleUpdatedABI, signerOrProvider);
};

// Helper function to ensure user is connected to BSC Testnet
export const ensureBSCTestnet = async () => {
  const provider = await detectEthereumProvider();
  
  if (!provider) {
    throw new Error('Please install MetaMask!');
  }
  
  // Get current chain id
  const chainId = await provider.request({ method: 'eth_chainId' });
  
  if (chainId !== BSC_TESTNET_CONFIG.chainId) {
    try {
      // Try to switch to BSC Testnet
      await provider.request({
        method: 'wallet_switchEthereumChain',
        params: [{ chainId: BSC_TESTNET_CONFIG.chainId }],
      });
    } catch (error) {
      // If the chain has not been added, add it
      if (error.code === 4902) {
        try {
          await provider.request({
            method: 'wallet_addEthereumChain',
            params: [BSC_TESTNET_CONFIG],
          });
        } catch (addError) {
          throw new Error('Failed to add BSC Testnet to MetaMask');
        }
      } else {
        throw new Error('Failed to switch to BSC Testnet');
      }
    }
  }
  
  return true;
};

// Helper function to connect wallet
export const connectWallet = async () => {
  try {
    const provider = await detectEthereumProvider();
    
    if (!provider) {
      throw new Error('Please install MetaMask!');
    }
    
    await ensureBSCTestnet();
    
    const accounts = await provider.request({
      method: 'eth_requestAccounts',
    });
    
    return accounts[0];
  } catch (error) {
    console.error('Error connecting wallet:', error);
    throw error;
  }
};

// Helper function to disconnect wallet
export const disconnectWallet = async () => {
  try {
    // Unfortunately, MetaMask doesn't provide a direct method to disconnect
    // We can only reset the connection state in our app
    // The user will remain logged into MetaMask
    
    // Clear any local wallet state
    localStorage.removeItem('walletConnected');
    
    // Return true to indicate successful disconnection (from the app's perspective)
    return true;
  } catch (error) {
    console.error('Error disconnecting wallet:', error);
    throw error;
  }
};

// Format amounts with proper decimals
export const formatAmount = (amount, decimals = 18) => {
  return ethers.utils.formatUnits(amount, decimals);
};

// Parse string amount to BigNumber with proper decimals
export const parseAmount = (amount, decimals = 18) => {
  return ethers.utils.parseUnits(amount.toString(), decimals);
};

// Generate shareable referral link
export const generateReferralLink = (address) => {
  const baseUrl = window.location.origin;
  return `${baseUrl}?ref=${address}`;
};

// Extract referrer from URL parameters
export const getReferrerFromUrl = () => {
  const urlParams = new URLSearchParams(window.location.search);
  return urlParams.get('ref') || ethers.constants.AddressZero;
};

// Helper function to check if address is valid
export const isValidAddress = (address) => {
  try {
    return ethers.utils.isAddress(address);
  } catch (error) {
    return false;
  }
};

// Helper function to shorten address for display
export const shortenAddress = (address) => {
  return `${address.substring(0, 6)}...${address.substring(address.length - 4)}`;
};